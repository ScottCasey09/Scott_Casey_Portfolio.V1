//
//  ViewController.swift
//  Message&ContactsUIFrameworks
//
//  Created by Casey Scott on 11/14/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import ContactsUI
import MessageUI

//Identifiers
private let cellID = "Cell"

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, CNContactPickerDelegate, CNContactViewControllerDelegate, MFMailComposeViewControllerDelegate {
    
    //Properties of the viewController
    //Data model for tableView
    var messages: [Emails] = []
    var contactsStore: CNContactStore?
    //Temp var to store the emailAddress
    var tempEmail: String?
    //Computed property for timeStamp
    var timeStamp: String{
        // *** Create date ***
        let dateFormatter = DateFormatter()
        //Set the way the time and date is presented
        dateFormatter.dateStyle = .medium
        dateFormatter.timeStyle = .medium
        //Instantiate a date object
        let date = Date()
        //Set format of the date to US
        dateFormatter.locale = Locale(identifier: "en_US")
        //Set the timeZone
        dateFormatter.timeZone = TimeZone(abbreviation: "EST")
        //return the date and time
        return dateFormatter.string(from: date)
    }
   
    
    //MARK: - Outlets
    
    @IBOutlet weak var tableView: UITableView!
    
    //MARK: - Load
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Create a variable to check the status of the user settings
        let status = CNContactStore.authorizationStatus(for: .contacts)
        
        if status == .authorized{
            contactsStore = CNContactStore()
            
        }else if status == .notDetermined{
            //Request access
            contactsStore?.requestAccess(for: .contacts, completionHandler: { (granted, error) in
                if let error = error{
                    print("Request access failed with error \(error)")
                }
                
                if granted{
                    print("Granted access")
                }else{
                    print("Not granted access")
                }
            })
        }else if status == .denied{
            //Inform the user to update settings
        }
    }
    
    //MARK: - Actions
    
    @IBAction func addNewButton(_ sender: UIBarButtonItem) {
        
        //Configure presentation to the add contact viewController
        let newContact = CNContactViewController(forNewContact: nil)
        //Assign the delegate
        newContact.delegate = self
        //Assign the ContactViewController a contact store
        newContact.contactStore = contactsStore
        //Check to see if the contacts caqn be edited
        if newContact.allowsEditing{
            //Embed the ContactsController in a nav controller
            let nav = UINavigationController(rootViewController: newContact)
            //Present the contactsController
            present(nav, animated: true, completion: nil)
        }
    }
    
    //Action for presenting the contacts
    @IBAction func contactsButton(_ sender: UIBarButtonItem) {
       
        //Configure presentating contacts list
        let list = CNContactPickerViewController()
        //Assign the ContactPicker to the view controller
        list.delegate = self
        //Present the contacts
        present(list, animated: true, completion: nil)
    }
    
    //MARK - CNContactViewControllerDelegate
    
    //Method called after the user sends or cancels an email
    func contactViewController(_ viewController: CNContactViewController, didCompleteWith contact: CNContact?) {
        
        //Print some check to the console
        if contact != nil{
            print("Contact saved")
            
        }else{
            print("Contact canceled")
        }
        //Dismis the view controller
        dismiss(animated: true, completion: nil)
    }
    //method called if the user selects an contact item
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contactProperty: CNContactProperty) {
        
        if contactProperty.key == "emailAddresses"{
        if MFMailComposeViewController.canSendMail(){
            //Instantiate the MailComposer
            let emailComposer = MFMailComposeViewController()
            //Assign the delegate
            emailComposer.mailComposeDelegate = self
            
            //Preset some properties of the composed email
            emailComposer.setToRecipients([String(describing: contactProperty.contact.emailAddresses[0].value)])
            tempEmail = String(describing: contactProperty.contact.emailAddresses[0].value)
            emailComposer.setSubject("A test EMail")
            //Pass in a little HTML
            emailComposer.setMessageBody("<p><strong>This is just a test message, disreguard.</strong></p>", isHTML: true)
            //Dismis the view controller before presenting the composer view
            dismiss(animated: true, completion: {
                //Present the composer View upon completion
                self.present(emailComposer, animated: true, completion: nil)
                
            })
        }
        }
    }
    
    
    //MARK: - MFMailComposeViewControllerDelegate
    
    //Method for dismissing the mail composer
    public func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?){
        //Check to see if there is an error
        if let error = error{
            print(error)
            return
        }
        // Check the result or perform other tasks.
        //Check for sent
        if result == .sent{
            if let email = tempEmail{
                let sentMail = Emails(emailAddress: email, timeStamp: timeStamp)
                self.messages += [sentMail]
            }
            //Reload the tableView
            tableView.reloadData()
            //Dismiss the view
            controller.dismiss(animated: true, completion: nil)
            
        }//Check for cancelled
        else if result == .cancelled{
            print("The message was canceled")
            controller.dismiss(animated: true, completion: nil)
            
        }//Check For failed
        else if result == .failed{
            //Create a Alert for a failed message
            let failedMessage = UIAlertController(title: "Attention", message: "Message failed to send.", preferredStyle: .actionSheet)
            //Create an action for the alert
            let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
            // Dismiss the mail compose view controller.
            controller.dismiss(animated: true, completion: nil)
            //Add the action
            failedMessage.addAction(ok)
            //Present the view controller
            present(failedMessage, animated: true, completion: nil)
            
        }//Check for saved
        else if result == .saved{
            
            print("Message has been saved")
        }
        
        
        
    }
    
    //MARK: - UITableViewDataSource
    
    //Set the row count
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    //Set the headding for each section
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Sent messages"
    }
    //Setup each cells data
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID) as! TableViewCell
        
        //Configure cell
        
        cell.emailAddress.text = messages[indexPath.row].emailAddress
        cell.timeStamp.text = messages[indexPath.row].timeStamp
        
        return cell
    }
    //Set the number of sections
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
}

