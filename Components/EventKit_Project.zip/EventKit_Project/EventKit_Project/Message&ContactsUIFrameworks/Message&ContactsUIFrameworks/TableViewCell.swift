//
//  TableViewCell.swift
//  Message&ContactsUIFrameworks
//
//  Created by Casey Scott on 11/14/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    //MARK: - Outlets

    @IBOutlet weak var emailAddress: UILabel!
    @IBOutlet weak var timeStamp: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
