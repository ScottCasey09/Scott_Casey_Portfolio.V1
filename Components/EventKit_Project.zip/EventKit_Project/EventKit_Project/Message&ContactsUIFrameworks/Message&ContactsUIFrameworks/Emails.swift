//
//  Emails.swift
//  Message&ContactsUIFrameworks
//
//  Created by Casey Scott on 11/15/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import Foundation

class Emails{
    
    var emailAddress: String
    var timeStamp: String
    
    init(emailAddress: String, timeStamp: String) {
        self.emailAddress = emailAddress
        self.timeStamp = timeStamp
    }
}
