//
//  CreateCalendarViewController.swift
//  EventKit_Project
//
//  Created by Casey Scott on 11/9/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import EventKitUI
import EventKit

class CreateCalendarViewController: UIViewController {

    //Properties of theis view controller
    var delegate: ViewController?
    var colors: [UIColor] = []
    
    //MARK: Outlets
    
    @IBOutlet weak var stepper: UIStepper!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    
    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Make array of random colors
        //Add some of the preset colors
        colors += [.blue, .red, .yellow, .brown, .black, .purple, .green]
        //Add random custom bolors
        for _ in 0...5{
            colors.append(UIColor(red: randomNumber(), green: randomNumber(), blue: randomNumber(), alpha: 1))
        }
        //Assign the starting color to the imageView
        imageView.backgroundColor = colors[0]
        //Assign the max value for the stepper
        stepper.maximumValue = Double(colors.count - 1)
        
       
    }

    //MARK: Actions
    
    //Go back to main viewController
    @IBAction func cancelButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    //Change the color of the calendar color
    @IBAction func changeColorSelection(_ sender: UIStepper) {
        imageView.backgroundColor = colors[Int(stepper.value)]
    }
    //Create a new Calendar
    @IBAction func createCalendar(sender: UIButton){
        //Check for blank text field
        if textField.text == "" || textField.text == " "{
            missingTextErrorMessage()
        }else{
            createNewCalendar()
        }
    }

    //MARK: Functions
    
    //Creates a random double between 0-1
    func randomNumber() ->CGFloat
    {
        let randomDouble = (Double(arc4random_uniform(UINT32_MAX))/Double(UINT32_MAX))
        let y = Double(round(randomDouble*10)/10)
        return CGFloat(y)
    }
    //Input error function for leaving the text field blank
    func missingTextErrorMessage(){
        let alert = UIAlertController(title: "Missing Input", message: "You must enter a title for your calendar", preferredStyle: .alert)
        
        let ok = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
        
        alert.addAction(ok)
        
        present(alert, animated: true, completion: nil)
    }
    //Function for creating a new calendar
    func  createNewCalendar(){
        //Check status
        //check delegate for nil
        if let delegates = delegate?.eventStore{
            //Instantiate a New calendar object
            let calendar = EKCalendar(for: .event, eventStore: delegates)
           delegate?.userCreatedCalendarID = calendar.calendarIdentifier
            //unwrap optional values of the UI elements
            //Assign a title to the calendar
            if let text = textField.text{
                calendar.title = text
            }
            //Assign a color to the calendar
            calendar.cgColor = (colors[Int(stepper.value)].cgColor)
            for source in delegates.sources{
                if source.sourceType == EKSourceType.local{
                    //We found a local source
                    calendar.source = source
                    break;
                }
            }
            //Save it to the database
            do{
                try delegates.saveCalendar(calendar, commit: true)
            }catch{
                print(error)
            }
            //Hide or show UI elements
            delegate?.displayChooserButton.isHidden = false
            delegate?.removeButton.isHidden = false
            delegate?.createButton.isHidden = true
            //Change the buttons Image
            delegate?.userCreatedCalendarImagebutton.setImage(#imageLiteral(resourceName: "calendarIcon"), for: .normal)
            //Go Back to the parent view
            dismiss(animated: true, completion: nil)

        }
    }
}
