//
//  ViewController.swift
//  EventKit_Project
//
//  Created by Casey Scott on 11/9/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import EventKit
import EventKitUI

class ViewController: UIViewController, EKCalendarChooserDelegate, EKEventEditViewDelegate {

    //Properties of this viewController
    let eventStore = EKEventStore()
    var calendarIdentifier: String = ""
    var userCreatedCalendarID: String = ""
    var selectedCalendarID: String = ""

    //MARK: Outlets
    
    @IBOutlet weak var displayChooserButton: UIButton!
    @IBOutlet weak var defaultCheckMark: UIImageView!
    @IBOutlet weak var userCheckMark: UIImageView!
    @IBOutlet weak var defaulfCalendarImageButton: UIButton!
    @IBOutlet weak var userCreatedCalendarImagebutton: UIButton!
    @IBOutlet weak var removalMessage: UILabel!
    @IBOutlet weak var createButton: UIButton!
    @IBOutlet weak var removeButton: UIButton!
    
    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let status = EKEventStore.authorizationStatus(for: .event)
        
        if status == .notDetermined{
            //request access
            eventStore.requestAccess(to: .event, completion: { (granted, error) in
                if let error = error{
                    print("Request Failed with error: \(error)")
                    return
                }
                if granted {
                    print("Granterd access")
                }else{
                    print("Denied")
                }
            })
        }
        //Clean up calendars that may have been created in other tests for the sake of this project
        for calendar in eventStore.calendars(for: .event){
            if calendar.title == "Default"{
            }else{
               try? eventStore.removeCalendar(calendar, commit: true)
            }
        }
        //Assign the selectedCalendarID var a value of the default Calendars ID
        selectedCalendarID = eventStore.defaultCalendarForNewEvents.calendarIdentifier
    }

    //MARK: Actions
    
    //Remove all events for the selected calendar
    @IBAction func removeAllEvents(_ sender: UIButton) {
        
        //Assign all the required paramaters for the predicate to constants
        let calendar: [EKCalendar]? = [eventStore.calendar(withIdentifier: selectedCalendarID)!]
        let startDate = NSDate().addingTimeInterval(-60*60*24)//In seconds
        let endDate = NSDate().addingTimeInterval(60*60*24*3)//In seconds
        //Assign the predicate to a constant
        let predicate = eventStore.predicateForEvents(withStart: startDate as Date, end: endDate as Date, calendars: calendar)
        //Assign the events array to a constant
        let events = eventStore.events(matching: predicate) as [EKEvent]!
        //Iterate over the array of events
        if let event = events {
            for i in event {
                //Remove the event from the calendar
                do{
                    try eventStore.remove(i, span: EKSpan.thisEvent, commit: true)
                }
                catch{
                    print(error)
                }
            }
        }
    }
    //Select the default calendar
    @IBAction func defaultCalendarSelected(_ sender: UIButton) {
        
        userCheckMark.isHidden = true
        defaultCheckMark.isHidden = false
        selectedCalendarID = eventStore.defaultCalendarForNewEvents.calendarIdentifier
    }
    //Select the user created calendar
    @IBAction func userCreatedCalendarSelected(_ sender: UIButton) {
        //Check for created calendar
        if userCreatedCalendarImagebutton.currentImage == #imageLiteral(resourceName: "NoCalendar"){
            //Do Nothing
        }
        else
        {
            userCheckMark.isHidden = false
            defaultCheckMark.isHidden = true
            selectedCalendarID = userCreatedCalendarID
        }
    }
    //Display the chooser view
    @IBAction func displayChooser(_ sender: UIButton) {
        
        //Instantiate the chooser
        let chooser = EKCalendarChooser(selectionStyle: .single, displayStyle: .allCalendars, entityType: .event, eventStore: eventStore)
        //Embed the chooser in a navigationController with buttons
        let navController = UINavigationController(rootViewController: chooser)
         chooser.showsDoneButton = true
        chooser.showsCancelButton = true
        chooser.delegate = self
        present(navController, animated: true, completion: nil)
    }
    //Display the event editing view
    @IBAction func displayEventEditing(_ sender: UIButton) {
        
        //Instantiate a EditViewController object
        let eventVC = EKEventEditViewController()
        //Assign the eventController to the eventStore object and present the view
        eventVC.eventStore = eventStore
        eventVC.editViewDelegate = self
        present(eventVC, animated: true, completion: nil)
        
    }
    //Remove the newly created calendar
    @IBAction func removeCalendar(_ sender: UIButton) {
        
        do{try eventStore.removeCalendar(eventStore.calendar(withIdentifier: userCreatedCalendarID)!, commit: true)
        }catch{
            print(error)
        }
        //hide and show UI elements to fit the requirements of the app
        removeButton.isHidden = true
        createButton.isHidden = false
        removalMessage.isHidden = false
        userCheckMark.isHidden = true
        defaultCheckMark.isHidden = false
        displayChooserButton.isHidden = true
        //Change the buttons Image
        userCreatedCalendarImagebutton.setImage(#imageLiteral(resourceName: "NoCalendar"), for: .normal)
    }

   //remove the message
    @IBAction func createNewButton(_ sender: UIButton) {
         removalMessage.isHidden = true
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       let destination = segue.destination as! CreateCalendarViewController
        //pass the viewController as a deleagte
        destination.delegate = self
    }
    
    //MARK: - EKEventEditViewDelegate
    
    //Assign the selected calendar to add events to
    func eventEditViewControllerDefaultCalendar(forNewEvents controller: EKEventEditViewController) -> EKCalendar {
        if let control = controller.eventStore.calendar(withIdentifier: selectedCalendarID){
        print("returned calendar")
        return control
        }
        return eventStore.defaultCalendarForNewEvents
    }
    //This method is required and used for dismissing the view
    func eventEditViewController(_ controller: EKEventEditViewController, didCompleteWith action: EKEventEditViewAction) {
        //Dismiss the view
        dismiss(animated: true, completion: nil)
    }
    
    //MARK: - EKCalendarChooserDelegate
    
    //Action for when the cancel button is pressed on the nav bar
    func calendarChooserDidCancel(_ calendarChooser: EKCalendarChooser) {
        dismiss(animated: true, completion: nil)
    }
    //Action for when the done button is pressed on the nav bar
    func calendarChooserDidFinish(_ calendarChooser: EKCalendarChooser) {
        for calendar in calendarChooser.selectedCalendars{
            
            calendarIdentifier = calendar.calendarIdentifier
        }
        
        dismiss(animated: true, completion: nil)
    }
    //When the selected calendar changezs this method is called
    func calendarChooserSelectionDidChange(_ calendarChooser: EKCalendarChooser) {
        
        //Iterate over the set to determine the selected calendars ID
        for calendar in calendarChooser.selectedCalendars{
            
            calendarIdentifier = calendar.calendarIdentifier
        }
        //Check to see which calendar is selected and assign the ID to the corrosponding Identifier, also update the UI Elements
        if calendarIdentifier == userCreatedCalendarID{
            
            userCheckMark.isHidden = false
            defaultCheckMark.isHidden = true
            selectedCalendarID = calendarIdentifier
        }
        else{
            userCheckMark.isHidden = true
            defaultCheckMark.isHidden = false
            selectedCalendarID = calendarIdentifier
        }
    }
}

