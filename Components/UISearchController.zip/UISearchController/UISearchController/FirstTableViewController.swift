//
//  FirstTableViewController.swift
//  UISearchController
//
//  Created by Casey Scott on 11/3/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class FirstTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //MARK: Properties
    
    //Array for the values of each cell
    var playersList: [Players] = []
    
    //MARK: Outlets
    
    //Outlet for referencing the tableView
    @IBOutlet weak var tableView: UITableView!
    
    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Actions
    
    @IBAction func clearAllRows(_ sender: AnyObject) {
        playersList = []
        tableView.reloadData()
    }

    // MARK: - Table view data source

    //Assign the number of sections, in this case return a hard 1
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    //Assigh the number of rows in the tableView based on teh count of the players array
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return playersList.count
    }
    //Assign values to each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FirstTableView") as! FirstTableViewCell

        // Configure the cell...
        
        cell.playerName.text = playersList[indexPath.row].name
        cell.numberLabel.text = String(playersList[indexPath.row].number)
        cell.teamLogo.image = playersList[indexPath.row].team

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
