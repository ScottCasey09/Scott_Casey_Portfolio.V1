//
//  BaseBallPlayers.swift
//  UISearchController
//
//  Created by Casey Scott on 11/3/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import Foundation
import UIKit

class Players{
    
    var name: String
    var team: UIImage?
    var number: Int
    
    
    init(name: String, team: UIImage, number: Int) {
        self.name = name
        self.team = team
        self.number = number
    }
}
