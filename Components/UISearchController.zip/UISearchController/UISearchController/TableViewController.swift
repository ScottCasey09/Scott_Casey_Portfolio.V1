//
//  TableViewController.swift
//  UISearchController
//
//  Created by Casey Scott on 11/3/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController, UISearchResultsUpdating, UISearchBarDelegate, UINavigationControllerDelegate {
    
    //MARK: Properties
    
    //Arrays for data
    var theCubs: [Players] = []
    var theIndians: [Players] = []
    var allPlayers: [Players] = []
    var filteredPlayers: [Players] = []
    //Property for search controller referencing
    var searchControllar = UISearchController(searchResultsController: nil)
    
    
    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Load the data model
        loadData()
        
        //Set the navigation collors delegate to this view controller
        navigationController?.delegate = self
        
        //Setup the search controller
        searchControllar.dimsBackgroundDuringPresentation = false
        self.definesPresentationContext = true
        
        //Setup search bar of search controller
        searchControllar.searchBar.scopeButtonTitles = ["ALL", "Cubs", "Indians"]
        searchControllar.searchBar.delegate = self
        //Add the searchbar to the table view
        tableView.tableHeaderView = searchControllar.searchBar
        searchControllar.searchBar.placeholder = "Enter a players name"
        
        //To fix some visual bugs sometimes with searchBar
        searchControllar.searchBar.sizeToFit()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - UISearchResultsUpdating
    
    func updateSearchResults(for searchController: UISearchController) {
        
        //Could not get this method to ever be called, even when the search bar became the first responder. So I went with the searchbar - textDidChange method
    }
    
    //MARK: - UISearchBarDelegate
    
    //Function for the change in scope
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        if selectedScope == 0{
            filteredPlayers = allPlayers
        }
        else if selectedScope == 1{
            filteredPlayers = theCubs
        }
        else if selectedScope == 2{
            filteredPlayers = theIndians
        }
        tableView.reloadData()
    }
    //Function for when the user enters text into the search bar
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //Assign the text of the search bar to a constant
        let searchText = searchControllar.searchBar.text!
 
        //Assign the scope index to a constant
        let selectedIndex = searchControllar.searchBar.selectedScopeButtonIndex
        
        //Filter based on the scope index
        if selectedIndex == 0{
            filteredPlayers = allPlayers
            if searchText.isEmpty == false{
                filteredPlayers = allPlayers.filter { (allPlayers) -> Bool in
                    allPlayers.name.lowercased().contains(searchText.lowercased())
                }
            }
        }else if selectedIndex == 1{
            filteredPlayers = theCubs
            if searchText.isEmpty == false{
                filteredPlayers = theCubs.filter { (allPlayers) -> Bool in
                    allPlayers.name.lowercased().contains(searchText.lowercased())
                }
            }
        }
        else if selectedIndex == 2{
            filteredPlayers = theIndians
            if searchText.isEmpty == false{
                filteredPlayers = theIndians.filter { (allPlayers) -> Bool in
                    allPlayers.name.lowercased().contains(searchText.lowercased())
                }
            }
        }
        //Reload the tableView
        tableView.reloadData()
    }
    
    
    // MARK: - Table view data source
    
    //Assign the number of sections in the table View
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    //Assign the number of rows in the tableView
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        if searchControllar.isActive{
            return filteredPlayers.count
        }
        return allPlayers.count
    }
    //Assign the values for each cell in the tableView
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCellSearch
        
        //If the search bar is being used, then use the filtered array
        if searchControllar.isActive{
            cell.nameLabel.text = filteredPlayers[indexPath.row].name
            cell.numberLabel.text = String(filteredPlayers[indexPath.row].number)
            cell.teamLogo.image = filteredPlayers[indexPath.row].team
            return cell
        }
        //Else return the cells using the allPlayers array
        cell.nameLabel.text = allPlayers[indexPath.row].name
        cell.numberLabel.text = String(allPlayers[indexPath.row].number)
        cell.teamLogo.image = allPlayers[indexPath.row].team
        return cell
    }
    
     // MARK: - Navigation
    
    //Pass the tableView back to the first TableViewController
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        // Here you pass the data back to your original view controller
        if let controller = viewController as? FirstTableViewController {
            if filteredPlayers.count == 0{
                controller.playersList = allPlayers
            }
            else{
                controller.playersList = filteredPlayers
            }
            controller.tableView.reloadData()
        }
    }
    
    //MARK: Functions
    
    //Data Model
    func loadData(){
        
        let cubs = [("Jake Arrieta", 49), ("Jake Buchanan", 43),("Trevor Cahill", 53),("Aroldis Chapman", 54),("Andury Acevedo",79),("Gerardo Concepcion",50),("Carl Edwards Jr.",6),("Justin Grimm",52),("Jason Hammel", 39),("Kyle Hendricks",28),("Pierce Johnson",80),("John Lackey",41),("Jon Lester",34),("Mike Montgomery",38),("Spencer Patton",45), ("Felix Pena", 60),("Hector Rondon", 56), ("Joe Smith", 30),("Pedro Strop", 46), ("Travis Wood",37),("Rob Zastryzny",29), ("Willson Contreras", 40),("Tim Federowicz",19),("Miguel Montero",47), ("David Ross", 3), ("Javier Baez", 9),("Kris Bryant",17), ("Jeimer Candelario",7), ("Munenori Kawasaki",66),("Tommy La Stella", 2), ("Anthony Rizzo", 44), ("Addison Russell", 27),("Ben Zobrist", 18), ("Albert Almora Jr.",5), ("Chris Coghlan",8), ("Dexter Fowler", 24), ("Jason Heyward", 22), ("Kyle Schwarber", 12), ("Jorge Soler", 68), ("Matt Szczur", 20)]
        
        for cub in cubs{
            
            theCubs.append(Players(name: cub.0, team: #imageLiteral(resourceName: "CubsLogo"), number: cub.1))
            allPlayers.append(Players(name: cub.0, team: #imageLiteral(resourceName: "CubsLogo"), number: cub.1))
            
        }
        
        let indians = [("Austin Adams", 49), ("Cody Allen", 37),("Cody Anderson", 56),("Shawn Armstrong", 51),("Dylan Baker",71),("Trevor Bauer",47),("Mike Clevinger",52),("Joseph Colon",65),("Kyle Crockett", 57),("Perci Garner",66),("Corey Kluber",28),("Jeff Manship",53),("Zach McAllister",34),("Ryan Merritt",54),("Andrew Miller",24), ("Shawn Morimando", 50),("Dan Otero", 61), ("Bryan Shaw", 27),("Josh Tomlin", 43), ("Chris Gimenez",38),("Yan Gomes",10), ("Adam Moore", 45),("Roberto Perez",55),("Jesus Aguilar",36), ("Erik Gonzalez", 9), ("Jason Kipnis", 22),("Francisco Lindor",12), ("Michael Martinez",1), ("Mike Napoli",26),("Jose Ramirez", 11), ("Giovanny Urshela", 39), ("Abraham Almonte", 35),("Marlon Byrd", 6), ("Lonnie Chisenhall",8), ("Coco Crisp",4), ("Rajai Davis", 20), ("Brandon Guyer", 6), ("Tyler Naquin", 30), ("Carlos Santana", 41), ("Adam Plutko", 62)]
        
        for indian in indians{
            
            theIndians.append(Players(name: indian.0, team: #imageLiteral(resourceName: "IndiansLogo"), number: indian.1))
            allPlayers.append(Players(name: indian.0, team: #imageLiteral(resourceName: "IndiansLogo"), number: indian.1))
        }
        //Sort all of the arrays in alphabetical order by player name
        allPlayers = allPlayers.sorted(by: { $0.name < $1.name })
        theCubs = theCubs.sorted(by: { $0.name < $1.name })
        theIndians = theIndians.sorted(by: { $0.name < $1.name })
        
    }
    
    
}

