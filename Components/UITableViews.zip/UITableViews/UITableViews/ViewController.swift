//
//  ViewController.swift
//  UITableViews
//
//  Created by Casey Scott on 10/25/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    //Properties of the first view controller
    var goldCoins: [Coins] = []
    var silverCoins: [Coins] = []
    var selectedCoin: Coins?
    
    //Load the View
    override func viewDidLoad() {
        super.viewDidLoad()
      
        //Data to populate the app with information
        //Set up the images for each item
        //Gold Coin Images
        let caracallaHerculesReversedImage = UIImage(named: "CaracallaGoldaureusOBV")
        let caracallaHerculesBothImage = UIImage(named: "CaracallaGoldaureus")
        let caracallaSimpulumReversedImage = UIImage(named: "CaracallaSimpulumObv")
        let caracallaSimpulumReversedImageBoth = UIImage(named: "CaracallaGoldAuresSimpulum")
        let caracallaGoldAuresGetaObvImage = UIImage(named: "CaracallaGoldAuresGetaObv")
        let caracallaGoldAuresGetaImageBoth = UIImage(named: "CaracallaGoldAuresGeta")
        let caracallaGoldAuresEmpVictoryImage = UIImage(named: "caracallaEmpVictoryImageObv")
        let caracallaGoldAuresEmpVictoryImageBoth = UIImage(named: "caracallaEmpVictoryBoth")
        let CaracallaGoldAuresMinervaImageObv = UIImage(named: "CaracallaGoldAuresMinervaImageObv")
        let caracallaGoldAuresMinervaImageBoth = UIImage(named: "CaracallaGoldAuresMinervaImageBoth")
        //Silver Coins Images
        let caracallaSilverDenMinervaImageObv = UIImage(named: "CaracallaSilverDenariusMinervaImageObv")
        let caracallaSilverDenMinervaImageBoth = UIImage(named: "CaracallaSilverDenariusMinervaImageBoth")
        let caracallaSilverDenSeptSevImageObv = UIImage(named: "CaracallaSilverDenSeptSevImageObv")
        let caracallaSilverDenSeptSevImageBoth = UIImage(named: "CaracallaSilverDenSeptSevImage")
        let caracallaSilverDenEmpImageObv = UIImage(named: "CaracallaSilverDenEmpImageObv")
        let caracallaSilverDenEmpImageBoth = UIImage(named: "CaracallaSilverDenEmpImageBoth")
        let caracallaSilverDenSalusImageObv = UIImage(named: "CaracallaSilverDenSalusImageObv")
        let caracallaSilverDenSalusImageBoth = UIImage(named: "CaracallaSilverDenSalusImageBoth")
        let caracallaSilverDenHorseImageObv = UIImage(named: "caracallaSilverDenHorseImageObv")
        let caracallaSilverDenHorseImageBoth = UIImage(named: "caracallaSilverDenHorseImageBoth")
        
        
        //Set up the list items
        //Gold coins
        let caracallaHerculesReversed = Coins(denomination: "Aureus", coinImage: caracallaHerculesReversedImage!, coinFrontBackImage:caracallaHerculesBothImage!,composition: "Gold", description: "ANTONINVS PIVS AVG, laureate head right / COS II, Hercules, seated left on a rock before a low table, left hand on club standing on the ground, and extending right hand; between togate figure of Potitus standing left, right arm raised and Pinarius, seated right. In the background five slaves, kneeling or standing, one of them offering Hercules a plate of food, crater on column with a large amphora at its base on the left, the entire scene between two trees with a large, garlanded basin above.", date: "207 AD.")
        let caracallaSimpulumReversed = Coins(denomination: "Aureus", coinImage: caracallaSimpulumReversedImage!,coinFrontBackImage: caracallaSimpulumReversedImageBoth!, composition: "Gold", description: "M AVR ANTONINVS CAES, draped bust right / SEVERI AVG PII FIL, lituus, axe, patera, jug, simpulum, and sprinkler. Cohen 582.", date: "169 AD.")
        let caracallaGoldAuresGeta = Coins(denomination: "Aureus", coinImage: caracallaGoldAuresGetaObvImage!, coinFrontBackImage: caracallaGoldAuresGetaImageBoth!, composition: "Gold", description: "M AVRELIVS ANTON AVG Laureate, draped and cuirassed bust right / P SEPT GETA CAES PONT Bare headed, draped and cuirassed bust of Geta right.", date: "198-201 AD.")
        let caracallaGoldAuresEmpVictory = Coins(denomination: "Aureus", coinImage: caracallaGoldAuresEmpVictoryImage!, coinFrontBackImage: caracallaGoldAuresEmpVictoryImageBoth!, composition: "Gold", description: "IMP CAES M AVR ANTONINVS AVG, laureate, draped and cuirassed bust right / IVVENTA IMPERII, Caracalla standing left, holding Victory on globe and spear, captive seated before in mourning attitude.", date: "198 Ad.")
        let caracallaGoldMinerva = Coins(denomination: "Aureus", coinImage: CaracallaGoldAuresMinervaImageObv!, coinFrontBackImage: caracallaGoldAuresMinervaImageBoth!, composition: "Gold", description: "IMP CAE M AVR ANT AVG P TR P, laureate, draped and cuirassed bust right / MINER VICTRIX, Minerva standing left, holding Victory and reversed spear; shield leaning against leg below and trophy behind.", date: "238-244 AD.")
        //Silver coins
        let caracallaSilverMinerva = Coins(denomination: "Denarius", coinImage: caracallaSilverDenMinervaImageObv!, coinFrontBackImage: caracallaSilverDenMinervaImageBoth!, composition: "Silver", description: "IMP CAE M AVR ANT AVG P TR P, laureate, draped bust right /MINER VICTRIX, Minerva standing left beside trophy, holding Victory and spear.", date: "238-244 AD.")
         let caracallaSilverDenSeptSev = Coins(denomination: "Denarius", coinImage: caracallaSilverDenSeptSevImageObv!, coinFrontBackImage: caracallaSilverDenSeptSevImageBoth!, composition: "Silver", description: "ANTONINVS AVGVSTUS, laureate, draped and cuirassed bust right / AETERNIT IMPERI, confronted busts of Septimius Severus, laureate, draped and cuirassed facing right and Caracalla, facing left.", date: "238-244 AD.")
        let caracallaSilverDenEmp = Coins(denomination: "Denarius", coinImage: caracallaSilverDenEmpImageObv!, coinFrontBackImage: caracallaSilverDenEmpImageBoth!, composition: "Silver", description: "AD. ANTONINVS AVGVSTVS, laureate draped bust right / RECTORI ORBIS, Caracalla standing left, holding globe and reversed spear.", date: "200 AD.")
        let caracallaSilverDenSalus = Coins(denomination: "Denarius", coinImage: caracallaSilverDenSalusImageObv!, coinFrontBackImage: caracallaSilverDenSalusImageBoth!, composition: "Silver", description: "ANTONINVS AVGVSTVS, laureate, draped and cuirassed bust right / SAL GEN HVM, Salus standing half-left, holding serpent-wreathed sceptre and extending hand to kneeling figure.", date: "238-244 AD.")
         let caracallaSilverDenHorse = Coins(denomination: "Denarius", coinImage: caracallaSilverDenHorseImageObv!, coinFrontBackImage: caracallaSilverDenHorseImageBoth!, composition: "Silver", description: "ANTONINVS PIVS AVG BRIT, laureate head right / PONTIF TR P XIII COS III, Caracalla on horseback galloping left, about to spear an enemy on the ground below.", date: "210 AD.")
        
        
        //Assign the array of coins a value containing all the items
        goldCoins = [caracallaHerculesReversed, caracallaSimpulumReversed, caracallaGoldAuresGeta,caracallaGoldAuresEmpVictory, caracallaGoldMinerva]
        silverCoins = [caracallaSilverMinerva, caracallaSilverDenSeptSev, caracallaSilverDenEmp, caracallaSilverDenSalus, caracallaSilverDenHorse]
    }
  
    //MARK: Functions
    
    //Set the number of sections in the Table View
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    //When a row cell is selected this func is called
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        //If a gold coin is selected assign the value to the selected coin object
        if indexPath.section == 0 {
            selectedCoin = goldCoins[indexPath.row]
        }
            //If a silver coin is selected assign the value to the selected coin object
        else if indexPath.section == 1 {
            selectedCoin = silverCoins[indexPath.row]
        }
        //perforn the segue to the DetailsViewController
        performSegue(withIdentifier: "GoToDetailsView", sender: self)
    }
    //Add values to the Table View from the Data Model
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //Reuse the table view objects,degueue an existing cell or reuse an existing one
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        
        //In the first section use gold coins array to assign the cell some values
        if indexPath.section == 0 {
        cell.coinImage.image = goldCoins[indexPath.row].coinImage
        cell.coinDescription.text = goldCoins[indexPath.row].description
        cell.coinLabel.text = goldCoins[indexPath.row].denomination
        }
            //In the second section use silver coins array to assign the cell some values
        else if indexPath.section == 1 {
            cell.coinImage.image = silverCoins[indexPath.row].coinImage
            cell.coinDescription.text = silverCoins[indexPath.row].description
            cell.coinLabel.text = silverCoins[indexPath.row].denomination
        }
        //Return the cell with values assigned
        return cell
    }
    //Set the number of rows in the Table View
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0{
            return goldCoins.count
        }else if section == 1{
            return silverCoins.count
        }else{
            return 0
        }
    }
    //Assign the section a title
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            return "Gold Coins"
        }
            //Because it's only 2 sections, no condition is required
        else {
            return "Silver Coins"
        }
    }
    //Prepare the Details View to display the values of the selected cell
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! DetailViewController
        
        //Pass the values to the properties of the details View
        destination.desc = (selectedCoin?.desc)!
        destination.date = (selectedCoin?.date)!
        destination.denom = (selectedCoin?.denomination)!
        destination.composition = (selectedCoin?.composition)!
        destination.image = selectedCoin?.coinFrontBackImage
        
    }
}

