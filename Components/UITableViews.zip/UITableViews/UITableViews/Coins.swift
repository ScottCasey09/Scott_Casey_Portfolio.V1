//
//  DataModel.swift
//  UITableViews
//
//  Created by Casey Scott on 10/25/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import Foundation
import  UIKit


class Coins{
    
    //MARK: Properties
    
    var denomination: String
    var coinImage: UIImage
    var coinFrontBackImage: UIImage
    var composition: String
    var description: String
    var date: String
    
    //Computed property for appending a citation to the website that provided the information (Data)
    var desc: String{
        
        return description + "\n\n\n\nAll images and information is credited to WildWinds.com"
    }
    
    //MARK: Initializer
    
    init(denomination: String, coinImage: UIImage, coinFrontBackImage: UIImage, composition: String, description: String, date: String) {
        self.denomination = denomination
        self.coinImage = coinImage
        self.coinFrontBackImage = coinFrontBackImage
        self.composition = composition
        self.description = description
        self.date = date
    }
}
