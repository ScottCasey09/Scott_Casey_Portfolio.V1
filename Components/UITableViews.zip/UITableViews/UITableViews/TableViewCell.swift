//
//  TableViewCell.swift
//  UITableViews
//
//  Created by Casey Scott on 10/25/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var coinLabel: UILabel!
    @IBOutlet weak var coinDescription: UITextView!
    @IBOutlet weak var coinImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
