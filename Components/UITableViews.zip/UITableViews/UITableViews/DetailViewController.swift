//
//  DetailViewController.swift
//  UITableViews
//
//  Created by Casey Scott on 10/25/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    //properties for the storyboard
    var date: String = ""
    var composition: String = ""
    var desc: String = ""
    var image: UIImage?
    var denom: String = ""
    
    //MARK: UIOutlets
    
    //outlets for the UI elements
    @IBOutlet weak var coinImage: UIImageView!
    @IBOutlet weak var coinDescription: UITextView!
    @IBOutlet weak var coinDate: UILabel!
    @IBOutlet weak var coinDenomination: UILabel!
    @IBOutlet weak var coinComposition: UILabel!
    
    //MARK: Actions
    
    //Go back to the first ViewController (TableView)
    @IBAction func goBackButton(_ sender: AnyObject) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // assign the Ui elements values from the selected cell
        coinImage.image = image
        coinDescription.text = desc
        coinDate.text = date
        coinComposition.text = composition
        coinDenomination.text = denom
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
