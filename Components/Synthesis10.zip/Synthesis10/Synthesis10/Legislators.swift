//
//  Legislators.swift
//  Synthesis10
//
//  Created by Casey Scott on 11/15/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import Foundation
import UIKit

class Legislator{
    //Properties
    var fullName: String
    var bioguide_id: String
    var party: String
    var title: String
    var stateOfResidence: String
    
    //Inatalizer for the class
    init() {
        
        fullName = "John Doe"
        bioguide_id = "0000000"
        party = "non-afil"
        title = "legislator"
        stateOfResidence = "U.S."
    }
    
     init(fullName: String, bioguide_id: String, party: String, title: String, stateOfResidence: String) {
        self.fullName = fullName
        self.bioguide_id = bioguide_id
        self.party = party
        self.title = title
        self.stateOfResidence = stateOfResidence
    }
}
