//
//  TableViewController.swift
//  Synthesis10
//
//  Created by Casey Scott on 11/15/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import WebKit

//Global variables
var frame = CGRect(x: 0, y: 35, width: 375, height: 546)
private let cellIdentifier = "Cell"
private let segeueToProfile = "ToLegislatorInfo"

class TableViewController: UITableViewController, URLSessionDelegate{
    
    //MARK: - Properties
    
    var legislators: [Legislator] = []
    var bioguide_IDs: [String] = []
    var firstNames: [String] = []
    var lastNames: [String] = []
    var middleNames: [String] = []
    var titles: [String] = []
    var statesOfResidences: [String] = []
    var parties: [String] = []
    var selectedLegislator = Legislator()
    var webView: WKWebView!
    var spinner: UIActivityIndicatorView!
    var count = 0
    
    //MARK: - Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Initalize the Activity indicator
        activityIndicator()
        spinner.isHidden = false
        spinner.startAnimating()
        
        //Instantiate a configuration
        let webConfiguration = WKWebViewConfiguration()
        
        //Set the size of the view
        webView = WKWebView(frame: frame, configuration: webConfiguration)
        
        //Instantiate an instance of a session configuration set to default
        let config = URLSessionConfiguration.default
        
        //Create a session
        let session = URLSession(configuration: config)
        var i = 1
        while i < 12{
            
            //Creat an unwraped instance of a url type
            if let requestURl = URL(string: "https://congress.api.sunlightfoundation.com/legislators?apikey=1f4393dfee044bb18bb580ef0beb9437?chamber=house&per_page=50&page=\(i)"){
                //Create an Url request
                let requestedURL = URLRequest(url: requestURl)
                //Assign to a variable the data task
                let task = session.dataTask(with: requestedURL, completionHandler: { (data, response, error) in
                    //Check against any errors
                    if let error = error{
                        print("Faild with error: \(error)")
                        print(requestURl)
                        return
                    }
                    print("Success")
                    //Check for success
                    if let http = response as? HTTPURLResponse{
                        if http.statusCode == 200{
                            print("Success at 200")
                            
                            //Dispatch the queue to the main thred
                            DispatchQueue.main.async {
                                //Parse the remote data
                                self.parseJSON(data: data!)
                            }
                        }
                    }
                })
                //resume the data task
                task.resume()
                
            }
            i += 1
        }
        
    }
    
    // MARK: - Table view data source
    
    //Set the number of sections
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    //Set the number of rows in each section
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return legislators.count
    }
    //Create and populate the rows in the table View
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Create a reuseable cell
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as! TableViewCell
        //Instantiate a temperory legislator object
        var cellLegislator: Legislator = Legislator()
        //Assign it the value of a legislator
        cellLegislator = legislators[indexPath.row]
        
        // Configure the cell...
        switch cellLegislator.party{
        case "Democrat":
            cell.backgroundColor = #colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 1)
        default:
            cell.backgroundColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
        }
        cell.nameLabel.text = cellLegislator.fullName
        cell.partyLabel.text = cellLegislator.party
        cell.residenceLabel.text = cellLegislator.stateOfResidence
        cell.titleLabel.text = cellLegislator.title
        return cell
    }
    
    //MARK: - Table View Delegation
    
    //Assign the selected row to the selectedLegislator
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedLegislator = legislators[indexPath.row]
        //Perform the segue
        performSegue(withIdentifier: segeueToProfile, sender: self)
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        let destination = segue.destination as! ProfileViewController
        // Pass the selected object to the new view controller.
        destination.legislator = selectedLegislator
        //Assign the nav controller header's title a value to display the name
        destination.title = selectedLegislator.fullName
        //pass each value of the selected legislators properties to the corrosponding elements of the ProfileViewController
        destination.party = selectedLegislator.party
        destination.legTitle = selectedLegislator.title
        destination.name = selectedLegislator.fullName
        destination.stateOfResidence = selectedLegislator.stateOfResidence
        destination.imageID = selectedLegislator.bioguide_id
        
        
    }
    
    //Function for parsing the JSON data
    private func parseJSON(data: Data){
        
        do{
            //Instantiate a legislator object
            var legislator = Legislator()
            
            //Instantiate a JSON converter object
            let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
            
            //Enter the dictionary
            if let rootDictionary: NSDictionary = json as? NSDictionary{
                
                //Find a key and use it to find the next value, save the value in an array
                if let rootData = rootDictionary["results"] as? [NSDictionary]{
                    for id in rootData{
                        if let results = id["bioguide_id"] as? String{
                            bioguide_IDs += [results]
                            print(results)
                        }
                        if let results = id["first_name"] as? String{
                            firstNames += [results]
                            print(results)
                        }
                        if let results = id["last_name"] as? String{
                            lastNames += [results]
                            print(results)
                        }
                        if let results = id["party"] as? String{
                            parties += [results]
                            print(results)
                        }
                        if let results = id["state_name"] as? String {
                            statesOfResidences += [results]
                            print(results)
                        }
                        if let results = id["title"] as? String{
                            titles += [results]
                            count += 1
                            print(results)
                        }
                    }
                }
                
            }else{
                print("Nothing Captured")
            }
            
            
            //Create the legislators objects
            for i in 0...firstNames.count-1{
                //Create a new entry
                legislator = Legislator(fullName: "\(firstNames[i]) \(lastNames[i])", bioguide_id: bioguide_IDs[i], party: parties[i], title: titles[i], stateOfResidence: statesOfResidences[i])
                //SAssign full party word to the proper legislator
                if legislator.party == "D"{
                    legislator.party = "Democrat"
                }else{
                    legislator.party = "Republican"
                }
                //Add the object to the data model
                legislators += [legislator]
            }
            //Catch any errors
        }catch{
            print(error)
        }
        //Reload the tableView Data
        tableView.reloadData()
        
        //Stop the annimation when the task is complete
        spinner.stopAnimating()
        spinner.isHidden = true
        
        //Print the count of the legislators to the console
        print("total \(count) ")
    }
    
    //Thif function instantiats a activity indicatorView
    func activityIndicator() {
        spinner = UIActivityIndicatorView(frame: frame)
        spinner.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        spinner.center = self.view.center
        self.view.addSubview(spinner)
    }
}
