//
//  ProfileViewController.swift
//  Synthesis10
//
//  Created by Casey Scott on 11/15/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import WebKit

class ProfileViewController: UIViewController, WKUIDelegate, WKNavigationDelegate{
    
    //MARK: - Outlets
    
    @IBOutlet weak var partyLable: UILabel!
    @IBOutlet weak var stateOfResidenceLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    
    //MARK: - Properties
    
    var name: String = ""
    var party: String = ""
    var legTitle: String = ""
    var stateOfResidence: String = ""
    var profileImage: UIImage?
    var legislator: Legislator?
    var imageID: String = ""
    var webView: WKWebView!
    var spinner: UIActivityIndicatorView!
    var uiWeb: UIWebView!
    
    
    //MARK: - Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        //Instantiate the activity indicator
        activityIndicator()
        //Reveal the avtivity Indicator
        spinner.isHidden = false
        //Start the animation
        spinner.startAnimating()
        
        //Assign the UI elements a value passed from the tableViewController
        nameLabel.text = name
        titleLabel.text = legTitle
        partyLable.text = party
        stateOfResidenceLabel.text = stateOfResidence
        
        // Do any additional setup after loading the view.
        
        //Instantiate a configuration
        let webConfiguration = WKWebViewConfiguration()
        //Set the size of the view and assign it a configuration
        webView = WKWebView(frame: frame, configuration: webConfiguration)
        //Assign the delegates of the webView
        webView.uiDelegate = self
        webView.navigationDelegate = self
        //Creat an unwraped instance of a url type
        let requestURl = URL(string: "https://theunitedstates.io/images/congress/225x275/\(imageID).jpg")
        //Create an Url request
        let requestedURL = URLRequest(url: requestURl!)
        //add the web view to the view
        view.addSubview(self.webView)
        //Send the view to the back of the view
        view.sendSubview(toBack: webView)

        //Load the URL to display in the webView
        webView.load(requestedURL)
        
    }
    
    //MARK: - WKNavigationDelegate

    //Handles when the loading stops
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        //Hide the activity indiactor
        spinner.isHidden = true
        //Stop the animation
        spinner.stopAnimating()
    }
    
    //Thif function instantiats a activity indicatorView and adds it to the view
    func activityIndicator() {
        spinner = UIActivityIndicatorView(frame: frame)
        spinner.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        spinner.center = self.view.center
        self.view.addSubview(spinner)
    }
}
