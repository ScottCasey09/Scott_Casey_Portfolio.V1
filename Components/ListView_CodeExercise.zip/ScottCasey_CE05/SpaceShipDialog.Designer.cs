﻿namespace ListViewForm
{
    partial class SpaceShipDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cruiserRadioButton = new System.Windows.Forms.RadioButton();
            this.freighterRadioButton = new System.Windows.Forms.RadioButton();
            this.destroyerRadioButton = new System.Windows.Forms.RadioButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.shipNameTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBoxForActiveDuty = new System.Windows.Forms.CheckBox();
            this.crewSizeUpDown = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.ApplyButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.crewSizeUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // cruiserRadioButton
            // 
            this.cruiserRadioButton.AutoSize = true;
            this.cruiserRadioButton.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.cruiserRadioButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cruiserRadioButton.Location = new System.Drawing.Point(63, 195);
            this.cruiserRadioButton.Name = "cruiserRadioButton";
            this.cruiserRadioButton.Size = new System.Drawing.Size(21, 20);
            this.cruiserRadioButton.TabIndex = 0;
            this.cruiserRadioButton.UseVisualStyleBackColor = false;
            this.cruiserRadioButton.CheckedChanged += new System.EventHandler(this.cruiserRadioButton_Click);
            // 
            // freighterRadioButton
            // 
            this.freighterRadioButton.AutoSize = true;
            this.freighterRadioButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.freighterRadioButton.Location = new System.Drawing.Point(327, 195);
            this.freighterRadioButton.Name = "freighterRadioButton";
            this.freighterRadioButton.Size = new System.Drawing.Size(21, 20);
            this.freighterRadioButton.TabIndex = 1;
            this.freighterRadioButton.UseVisualStyleBackColor = true;
            this.freighterRadioButton.CheckedChanged += new System.EventHandler(this.freighterRadioButton_Click);
            // 
            // destroyerRadioButton
            // 
            this.destroyerRadioButton.AutoSize = true;
            this.destroyerRadioButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.destroyerRadioButton.Location = new System.Drawing.Point(194, 195);
            this.destroyerRadioButton.Name = "destroyerRadioButton";
            this.destroyerRadioButton.Size = new System.Drawing.Size(21, 20);
            this.destroyerRadioButton.TabIndex = 2;
            this.destroyerRadioButton.UseVisualStyleBackColor = true;
            this.destroyerRadioButton.CheckedChanged += new System.EventHandler(this.destroyerRadioButton_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ListViewForm.Properties.Resources.freighter;
            this.pictureBox3.Location = new System.Drawing.Point(274, 76);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(124, 113);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ListViewForm.Properties.Resources.destroyer;
            this.pictureBox2.Location = new System.Drawing.Point(144, 76);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(124, 113);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ListViewForm.Properties.Resources.cruiser;
            this.pictureBox1.Location = new System.Drawing.Point(14, 76);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Cruiser";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(165, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Destroyer";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(297, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Freighter";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cruiserRadioButton);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.freighterRadioButton);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.destroyerRadioButton);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Location = new System.Drawing.Point(12, 156);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(424, 224);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Ship";
            // 
            // shipNameTextBox
            // 
            this.shipNameTextBox.Location = new System.Drawing.Point(26, 91);
            this.shipNameTextBox.Name = "shipNameTextBox";
            this.shipNameTextBox.Size = new System.Drawing.Size(158, 26);
            this.shipNameTextBox.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Ship Name";
            // 
            // checkBoxForActiveDuty
            // 
            this.checkBoxForActiveDuty.AutoSize = true;
            this.checkBoxForActiveDuty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBoxForActiveDuty.Location = new System.Drawing.Point(313, 83);
            this.checkBoxForActiveDuty.Name = "checkBoxForActiveDuty";
            this.checkBoxForActiveDuty.Size = new System.Drawing.Size(115, 44);
            this.checkBoxForActiveDuty.TabIndex = 9;
            this.checkBoxForActiveDuty.Text = "Active Duty\r\n Is Present";
            this.checkBoxForActiveDuty.UseVisualStyleBackColor = true;
            // 
            // crewSizeUpDown
            // 
            this.crewSizeUpDown.Cursor = System.Windows.Forms.Cursors.Hand;
            this.crewSizeUpDown.Location = new System.Drawing.Point(217, 92);
            this.crewSizeUpDown.Name = "crewSizeUpDown";
            this.crewSizeUpDown.Size = new System.Drawing.Size(76, 26);
            this.crewSizeUpDown.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(213, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "Crew Size";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sitka Text", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(0, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(451, 63);
            this.label6.TabIndex = 13;
            this.label6.Text = "Create A Spacecraft";
            // 
            // okButton
            // 
            this.okButton.AutoSize = true;
            this.okButton.BackColor = System.Drawing.SystemColors.HotTrack;
            this.okButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.okButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.okButton.Location = new System.Drawing.Point(45, 429);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(105, 59);
            this.okButton.TabIndex = 14;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = false;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.AutoSize = true;
            this.cancelButton.BackColor = System.Drawing.SystemColors.Menu;
            this.cancelButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cancelButton.Location = new System.Drawing.Point(339, 456);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(76, 32);
            this.cancelButton.TabIndex = 15;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = false;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // ApplyButton
            // 
            this.ApplyButton.AutoSize = true;
            this.ApplyButton.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ApplyButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ApplyButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ApplyButton.Location = new System.Drawing.Point(181, 429);
            this.ApplyButton.Name = "ApplyButton";
            this.ApplyButton.Size = new System.Drawing.Size(99, 59);
            this.ApplyButton.TabIndex = 16;
            this.ApplyButton.Text = "Apply";
            this.ApplyButton.UseVisualStyleBackColor = false;
            this.ApplyButton.Visible = false;
            this.ApplyButton.Click += new System.EventHandler(this.ApplyButton_Click);
            // 
            // SpaceShipDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(448, 606);
            this.Controls.Add(this.ApplyButton);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.crewSizeUpDown);
            this.Controls.Add(this.checkBoxForActiveDuty);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.shipNameTextBox);
            this.Controls.Add(this.groupBox1);
            this.Name = "SpaceShipDialog";
            this.Text = "SpaceShipDialog";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.crewSizeUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        public System.Windows.Forms.RadioButton cruiserRadioButton;
        public System.Windows.Forms.RadioButton freighterRadioButton;
        public System.Windows.Forms.RadioButton destroyerRadioButton;
        public System.Windows.Forms.TextBox shipNameTextBox;
        public System.Windows.Forms.CheckBox checkBoxForActiveDuty;
        public System.Windows.Forms.NumericUpDown crewSizeUpDown;
        public System.Windows.Forms.Button ApplyButton;
    }
}