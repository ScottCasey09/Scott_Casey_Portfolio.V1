﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListViewForm
{
    public class SpaceShip
    {
        string name;
        decimal crewCount;
        bool activeDuty;
        bool cruiser;
        bool destroyer;
        bool freighter;
        int imageIndexer;

        public int ImageIndexer
        {
            get
            {
                return imageIndexer;
            }set
            {
                imageIndexer = value;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }set
            {
                name = value;
            }
        }public decimal CrewCount
        {
            get
            {
                return crewCount;
            }set
            {
                crewCount = value;
            }
        }public bool ActiveDuty
        {
            get
            {
                return activeDuty;
            }set
            {
                activeDuty = value;
            }
        }public bool Cruiser
        {
            get
            {
                return cruiser;
            }
            set
            {
                cruiser = value;
            }
        }public bool Destroyter
        {
            get
            {
                return destroyer;
            }set
            {
                destroyer = value;
            }
        }public bool Freightwer
        {
            get
            {
                return freighter;
            }set
            {
                freighter = value;
            }
        }
        public SpaceShip()
        {
            name = "";
            crewCount = 0;
            activeDuty = false;
            cruiser = false;
            destroyer = false;
            freighter = false;
        }
        public override String ToString()
        {
            return name;
        }
    }
}
