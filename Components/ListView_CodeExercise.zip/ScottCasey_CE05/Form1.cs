﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListViewForm
{
    
    public partial class ListViewForm : Form
    {

        public EventHandler<ModifyObjectEventArgs> ModifyObject;


        public SpaceShip SelectedObject
        {
            get
            {
                if (listView1.Items.Count > 0)
                {
                    return listView1.SelectedItems[0].Tag as SpaceShip;
                }
                else
                {
                    return new SpaceShip();
                }
            }
        }
        public ListViewForm()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SpaceShipDialog ssd = new SpaceShipDialog();
        
                ssd.OkButtonPressedEvent += AddToListViewHandler;

                ssd.ShowDialog();
            
        } 
       


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void largeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(smallToolStripMenuItem.Checked == true)
            {
                smallToolStripMenuItem.Checked = false;
            }
            if(largeToolStripMenuItem.Checked != true)
            {
                largeToolStripMenuItem.Checked = true;
            }
            listView1.View = View.LargeIcon;
        }

        private void smallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(largeToolStripMenuItem.Checked == true)
            {
                largeToolStripMenuItem.Checked = false;
            }
            if (smallToolStripMenuItem.Checked != true)
            {
                smallToolStripMenuItem.Checked = true;
            }
            listView1.View = View.SmallIcon;
        }
        public void AddToListViewHandler(object sender,EventArgs e)
        {
            SpaceShip ss = new SpaceShip();
            SpaceShipDialog ssd = sender as SpaceShipDialog;
            if (ssd.shipNameTextBox.Text != "")
            {
                if (ssd.cruiserRadioButton.Checked == true)
                {
                   
                    ss = ssd.Data;
                    
                }
                else if (ssd.destroyerRadioButton.Checked == true)
                {
                   
                    ss = ssd.Data;
                   
                }
                else if (ssd.freighterRadioButton.Checked == true)
                {
                    
                    ss = ssd.Data;
                    
                }
                else
                {
                    MessageBox.Show("Select the type of ship you wish to create.");
                }
                ListViewItem lvi = new ListViewItem();

                lvi.Text = ss.ToString();
                lvi.ImageIndex = ss.ImageIndexer;
                lvi.Tag = ss;
                listView1.Items.Add(lvi);
                ssd.Data = new SpaceShip();
                ssd.Close();
                toolStripStatusLabel1.Text = "Items in lsit" + " " + "[" + listView1.Items.Count + "]";
            }
            else
            {
                MessageBox.Show("You did not enter a name for the spacecraft. Please enter a name in the text box.");
            }
            

        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.Clear();
            toolStripStatusLabel1.Text = "Items in lsit" + " " + "[" + listView1.Items.Count + "]";
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            
            SpaceShipDialog ssd = new SpaceShipDialog();
            ssd.ApplyButtonClickedEvent += ApplyButtonWasClicked;
            ModifyObject += ssd.HandleModifyObject;
            ssd.Data = SelectedObject;
            ssd.ApplyButton.Visible = true;
            ssd.OkButtonPressedEvent += AddToListViewHandler;
            ssd.ShowDialog();
            


        }
        public class ModifyObjectEventArgs : EventArgs
        {
            ListViewItem ObjectToModify;
            public ListViewItem ItemToModifyProperty
            {
                get
                {
                    return ObjectToModify;
                }
                set
                {
                    ObjectToModify = value;
                }
            }
            public ModifyObjectEventArgs(ListViewItem lvi)
            {
                ObjectToModify = lvi;
            }
        }
        public void ApplyButtonWasClicked(object sender, EventArgs e)
        {
            ModifyObject?.Invoke(this, new ModifyObjectEventArgs(listView1.SelectedItems[0]));
        }

        private void ListViewForm_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Items in lsit" + " " + "[" + listView1.Items.Count + "]";
        }
    }
}
