﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListViewForm
{
    public partial class SpaceShipDialog : Form
    {
        public EventHandler OkButtonPressedEvent;
    
        public EventHandler ApplyButtonClickedEvent;
        public EventHandler OpenDialogWithApply;


        public SpaceShipDialog()
        {
            InitializeComponent();
        }

        public SpaceShip Data
        {

            get
            {
                SpaceShip ss = new SpaceShip();
                ss.Name = shipNameTextBox.Text;
                ss.CrewCount = crewSizeUpDown.Value;
                ss.ActiveDuty = checkBoxForActiveDuty.Checked;
                ss.Cruiser = cruiserRadioButton.Checked;
                ss.Destroyter = destroyerRadioButton.Checked;
                ss.Freightwer = freighterRadioButton.Checked;
                if (cruiserRadioButton.Checked == true)
                {
                    ss.ImageIndexer = 0;
                }
                else if (destroyerRadioButton.Checked == true)
                {
                    ss.ImageIndexer = 1;
                }
                else if (freighterRadioButton.Checked == true)
                {
                    ss.ImageIndexer = 2;
                }
                
                return ss;
            }
            set
            {
                shipNameTextBox.Text = value.Name;
                crewSizeUpDown.Value = value.CrewCount;
                checkBoxForActiveDuty.Checked = value.ActiveDuty;
                cruiserRadioButton.Checked = value.Cruiser;
                destroyerRadioButton.Checked = value.Destroyter;
                freighterRadioButton.Checked = value.Freightwer;

            }
        }
        private void okButton_Click(object sender, EventArgs e)
        {

            OkButtonPressedEvent?.Invoke(this, new EventArgs());

        }
        public void OpenDialogWithSelectedShip(object sender, EventArgs e)
        {
            

            OpenDialogWithApply?.Invoke(this, new EventArgs());
            ApplyButton.Visible = true;

        }

        private void cruiserRadioButton_Click(object sender, EventArgs e)
        {
            destroyerRadioButton.Checked = false;
            freighterRadioButton.Checked = false;

            
        }

        private void destroyerRadioButton_Click(object sender, EventArgs e)
        {
            
            freighterRadioButton.Checked = false;
            cruiserRadioButton.Checked = false;
       
        }

        private void freighterRadioButton_Click(object sender, EventArgs e)
        {
            
            destroyerRadioButton.Checked = false;
            cruiserRadioButton.Checked = false;

        }


        private void ApplyButton_Click(object sender, EventArgs e)
        {
            if (shipNameTextBox.Text != "")
            {
                if (cruiserRadioButton.Checked == true)
                {

                    
                    ApplyButtonClickedEvent?.Invoke(this, new EventArgs());
                    Close();

                }
                else if (destroyerRadioButton.Checked == true)
                {

                    ApplyButtonClickedEvent?.Invoke(this, new EventArgs());
                    Close();

                }
                else if (freighterRadioButton.Checked == true)
                { 
                    ApplyButtonClickedEvent?.Invoke(this, new EventArgs());
                    Close();

                }
                else
                {
                    MessageBox.Show("Select the type of ship you wish to create.");
                }
               
            }
            else
            {
                MessageBox.Show("You did not enter a name for the spacecraft. Please enter a name in the text box.");
            }

            
            
        }
        public void HandleModifyObject(object sender, ListViewForm.ModifyObjectEventArgs e)
        {
            SpaceShip ss = e.ItemToModifyProperty.Tag as SpaceShip;
            ss.Name = shipNameTextBox.Text;
            ss.CrewCount = crewSizeUpDown.Value;
            ss.ActiveDuty = checkBoxForActiveDuty.Checked;
            ss.Cruiser = cruiserRadioButton.Checked;
            ss.Destroyter = destroyerRadioButton.Checked;
            ss.Freightwer = freighterRadioButton.Checked;
            if (cruiserRadioButton.Checked == true)
            {
                ss.ImageIndexer = 0;
            }
            else if (destroyerRadioButton.Checked == true)
            {
                ss.ImageIndexer = 1;
            }
            else if (freighterRadioButton.Checked == true)
            {
                ss.ImageIndexer = 2;
            }
            e.ItemToModifyProperty.Text = ss.ToString();
            e.ItemToModifyProperty.ImageIndex = ss.ImageIndexer;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
