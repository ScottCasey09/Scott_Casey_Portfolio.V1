//
//  SecondTabView.swift
//  UITabBar&NavControllers
//
//  Created by Casey Scott on 10/31/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class SecondTabView: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UITextFieldDelegate {

    //MARK: UIOutlets
    
    @IBOutlet weak var firstNum: UILabel!
    @IBOutlet weak var answer: UILabel!
    @IBOutlet weak var pickerViewUIEmement: UIPickerView!
    @IBOutlet weak var pickerViewToggleButton: UIButton!
   
    //Data for picker view
    var pickerDataA: [Int] = []
    
    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Add Values 0-100 to the array
        for num in 0...100{
            pickerDataA.append(num)
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
       
        
    }
    
    //MARK: Actions
    
    //Button for turning on and off the pickerView
    @IBAction func turnOnOffPicker(_ sender: AnyObject) {
        //Check to see the state of which the picker is set at
        //If the picker is on
        if pickerViewUIEmement.isHidden == false{
            pickerViewUIEmement.isHidden = true
            pickerViewToggleButton.setTitle("Turn ON", for: .normal)
            
        }//If the picker is off turn it on and change the state of the button
        else{
            pickerViewUIEmement.isHidden = false
            pickerViewToggleButton.setTitle("Turn OFF", for: .normal)
            firstNum.text = String(pickerDataA[0])
            pickerViewUIEmement.selectRow(0, inComponent: 0, animated: true)
            //Display the answer for the number selected in the pickerview X10
            answer.text = String(10 * pickerDataA[0])
        }
    }
    
    //MARK: PickerView
    
    //Establish how many sections the PickerView Will have
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    //Establish how many selections the pickerview will have
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return pickerDataA.count
        
    }
    //Load the values ointo the pickerView object
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return String(pickerDataA[row])
        
    }
    //React to the value changing
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //Change the first number to the selected row in the pickerView
        firstNum.text = String(pickerDataA[row])
        //Display the answer for the number selected in the pickerview X10
        answer.text = String(10 * pickerDataA[row])
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
