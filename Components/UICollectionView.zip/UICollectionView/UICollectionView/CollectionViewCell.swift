//
//  CollectionViewCell.swift
//  UICollectionView
//
//  Created by Casey Scott on 11/1/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewCell: UIImageView!
    @IBOutlet weak var cellLabel: UILabel!
    
    
}
