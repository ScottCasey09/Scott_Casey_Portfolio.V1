//
//  CollectionReusableView.swift
//  UICollectionView
//
//  Created by Casey Scott on 11/1/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {
    
    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var deleteSectionsButton: UIButton!
        
}
