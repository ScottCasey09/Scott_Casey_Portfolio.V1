//
//  CollectionViewController.swift
//  UICollectionView
//
//  Created by Casey Scott on 11/1/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

//Identifiers
let reuseableIdentifier = "Header"
let collectionCell = "Cell"

//Data Properties
var icons: [String: [Cells]] = [:]
var iconKeys = Array(icons.keys)

class CollectionViewController: UICollectionViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        //Load the data to the view
        loadData()
     
    }
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Action for reacting to the user tapping the delete section button
    @IBAction func removeSectionButtonPress(_ sender: UIButton) {
        //Assign the value of the buttons tag property
        let section = sender.tag
        //Update the data model
        icons.removeValue(forKey: iconKeys[section])
        iconKeys.remove(at: section)
        //Delete the section from the collection view
        collectionView?.performBatchUpdates({ 
            self.collectionView?.deleteSections(NSIndexSet(index: section) as IndexSet)
            //If that deletion did take place and is finished then reload the data
            }, completion: { (finished) in
                if finished{
                    self.collectionView?.reloadData()
                }
        })
       
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView{
        
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: reuseableIdentifier, for: indexPath) as! CollectionReusableView
        
        //Configure the header
     
            header.headerLabel.text = iconKeys[indexPath.section]
            header.deleteSectionsButton.tag = indexPath.section
        
        return header
        
    }
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return icons.keys.count
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // Return the count of eactions objects
            if let icon = icons[iconKeys[section]]{
            return icon.count
              }
        return 0
    }
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: collectionCell, for: indexPath) as! CollectionViewCell
    
        //Check to see if they key exists and configure the cell for the section
            if let icon = icons[iconKeys[indexPath.section]]{
                cell.cellLabel.text = icon[indexPath.row].title
                cell.imageViewCell.image = icon[indexPath.row].image
            }
        return cell
    }

    // MARK: UICollectionViewDelegate

    
    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

    //MARK: - Functions
    
    //Data Model
    func loadData(){
        
        let airplane = Cells(title: "Air Plane", image: #imageLiteral(resourceName: "AirPlane"))
        let star = Cells(title: "Star", image: #imageLiteral(resourceName: "Star"))
        let thumbsUp = Cells(title: "Thumb Up", image: #imageLiteral(resourceName: "ThumbUP"))
        let music = Cells(title: "Music Note", image: #imageLiteral(resourceName: "MusicNote"))
        let paw = Cells(title: "Paw Print", image: #imageLiteral(resourceName: "PawPrint"))
        
        let visa = Cells(title: "Visa", image: #imageLiteral(resourceName: "VisaCard"))
        let masterCard = Cells(title: "Master Card", image: #imageLiteral(resourceName: "MasterCard"))
        let payPal = Cells(title: "Pay Pal", image: #imageLiteral(resourceName: "PayPalCard"))
        let americanExpress = Cells(title: "American Express", image: #imageLiteral(resourceName: "AmericanExpressCard"))
        let discover = Cells(title: "Discover", image: #imageLiteral(resourceName: "DiscoverCard"))
        
        let twitter = Cells(title: "Twitter", image: #imageLiteral(resourceName: "Twitter"))
        let twitch = Cells(title: "Twitch", image: #imageLiteral(resourceName: "Twitch"))
        let facebook = Cells(title: "Facebook", image: #imageLiteral(resourceName: "FaceBook"))
        let yelp = Cells(title: "Yelp", image: #imageLiteral(resourceName: "Yelp"))
        let linkedIn = Cells(title: "LinkedIn", image: #imageLiteral(resourceName: "LinkedIn"))
        
        icons = ["Credit Cards": [visa, masterCard, payPal, americanExpress, discover], "Social Media": [twitch, facebook,twitter, yelp, linkedIn], "Random Icons": [airplane, star, thumbsUp, music, paw]]
        
    }
}
