//
//  CellObjects.swift
//  UICollectionView
//
//  Created by Casey Scott on 11/1/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import Foundation
import UIKit

class Cells{
    
    //Properties of each cell
    var title: String
    var image: UIImage?
    
    //Initializer
    init(title: String, image: UIImage) {
        self.title = title
        self.image = image
    }
}
