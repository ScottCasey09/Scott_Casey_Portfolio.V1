﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;

namespace Project_Smile
{
    class Program
    {
        static void Main(string[] args)
        {
            //Smile face layeout array
            int[,] smile = new int[10, 16] {

                {0,0,0,0,5,5,5,5,5,5,5,5,0,0,0,0},
                {0,0,5,4,4,4,4,4,4,4,4,4,4,5,0,0},
                {0,5,4,4,4,4,4,4,4,4,4,4,4,4,5,0},
                {5,4,4,6,6,6,4,4,4,4,6,6,6,4,4,5},
                {5,4,4,0,0,0,4,4,4,4,0,0,0,4,4,5},
                {5,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5},
                {5,4,4,4,4,0,4,4,4,4,4,0,4,4,4,5},
                {0,5,4,4,4,4,0,0,0,0,0,4,4,4,5,0},
                {0,0,5,4,4,4,4,4,4,4,4,4,4,5,0,0},
                {0,0,0,0,5,5,5,5,5,5,5,5,0,0,0,0}};
           
            //Design characters
            char[] detail = new char[] { '!', '?', '>', '#', '@', '^', '&', '*', '$','<' };

            //Spacer from top
            Console.WriteLine("\r\n");

            //Loop for y axis
            for (
                int x = 0; x < 10; x++)
            {
                Console.Write("     ");
                for (int y = 0; y < 16; y++)
                {
                    Console.Write("");
                   
                    if (smile[x,y] == 0)
                    {
                        Console.Write(" ");
                    }
                    else
                    {
                        switch (smile[x, y])
                        {
                            case 1:
                                Console.Write(detail[0]);
                                break;
                            case 2:
                                Console.Write(detail[1]);
                                break;
                            case 3:
                                Console.Write(detail[2]);
                                break;
                            case 4:
                                Console.Write(detail[3]);
                                break;
                            case 5:
                                Console.Write(detail[4]);
                                break;
                            case 6:
                                Console.Write(detail[5]);
                                break;
                            case 7:
                                Console.Write(detail[6]);
                                break;
                            case 8:
                                Console.Write(detail[7]);
                                break;
                            case 9:
                                Console.Write(detail[8]);
                                break;
                            case 10:
                                Console.Write(detail[9]);
                                break;


                        }
                    }
                    
                }
                Console.WriteLine();


            }
            Console.ReadKey();
        }
    }
}
