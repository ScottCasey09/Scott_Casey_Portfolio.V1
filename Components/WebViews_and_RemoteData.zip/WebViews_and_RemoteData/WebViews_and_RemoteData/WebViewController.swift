//
//  WebViewController.swift
//  WebViews_and_RemoteData
//
//  Created by Casey Scott on 11/11/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import WebKit



class WebViewController: UIViewController, UITextFieldDelegate, WKUIDelegate, UITextViewDelegate, UIWebViewDelegate{
    
    //Properties of the view controller
    var webView: WKWebView!
    var frame = CGRect(x: 0, y: 35, width: 375, height: 546)
    
    //MARK - Outlets
    
    @IBOutlet weak var textFieldURL: UITextField!
    @IBOutlet weak var forwardButton: UIBarButtonItem!
    @IBOutlet weak var backButton: UIBarButtonItem!
    @IBOutlet weak var toolBar: UIToolbar!

    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Create the views
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: frame, configuration: webConfiguration)
        let views = UIView(frame: frame)
        view.insertSubview(views, aboveSubview: view)
        view.insertSubview(toolBar, aboveSubview: views)
        views.addSubview(webView)
        //Assign the delegate
        webView.uiDelegate = self
        //Assign a default web page
        let myURL = URL(string: "https://www.apple.com")
        let myRequest = URLRequest(url: myURL!)
        webView.allowsBackForwardNavigationGestures = true
       //Disable back and forward buttons
        backButton.isEnabled = false
        forwardButton.isEnabled = false
        //Load the view
        webView.load(myRequest)
    }
    
    //MARK: Actions
    
    //Action for pressing back button
    @IBAction func backButton(_ sender: AnyObject) {
        
        //Check if user can go back
        if webView.canGoBack == true{
            webView.goBack()
            forwardButton.isEnabled = true
        }
        //check again for more, if no then disable the button
        if webView.canGoBack == false{
            backButton.isEnabled = false
        }
    }
    //Action for pressing forward button
    @IBAction func forwardButton(_ sender: AnyObject) {
        
        //Check if user can go forward
        if webView.canGoForward == true{
            webView.goForward()
            backButton.isEnabled = true
        }
        //Check again, if no then disable the button
        if webView.canGoForward == false{
            forwardButton.isEnabled = false
            }
        
    }
    //Action for pressing refresh button
    @IBAction func refreshButton(_ sender: AnyObject) {
        
        //refresh the view
        webView.reload()
        
    }
    //Action for pressing search button
    @IBAction func searchButton(_ sender: UIBarButtonItem) {
        performSearch()
    }
    
    //MARK: - UITextFieldDelegate
    
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       performSearch()
    //resign the keyboard
    textFieldURL.resignFirstResponder()
    return true
    }
    
    //MARK: Custom Functions
    
    //Fiunction for performing a search of the web in the WbeView
    func performSearch(){
        
        //Instantiate an instance of a configuration
        let config = URLSessionConfiguration.default
        
        //Create a session
        let session = URLSession(configuration: config)
        
        //Check for blank field
        if textFieldURL.text == "" || textFieldURL.text == "" || textFieldURL.text == nil{
            //do nothing
        }else{
        //Unwrap the textField
        if let url = textFieldURL.text{
            
            //Creat an unwraped instance of a url type
            if let requestURl = URL(string: url){
                //Create an Url request
                let requestedURL = URLRequest(url: requestURl)
                //Assign to a variable the data task
                let task = session.dataTask(with: requestedURL, completionHandler: { (data, response, error) in
                    //Check against any errors
                    if let error = error{
                        print("Faild with error: \(error)")
                        print(requestURl)
                        return
                    }
                    print("Success")
                    //Check for success
                    if let http = response as? HTTPURLResponse{
                        if http.statusCode == 200{
                            
                            //Dispatch to the main thred
                            DispatchQueue.main.async {
                                //Load the webPage
                                self.webView.load(requestedURL)
                            }
                        }
                    }
                })
                task.resume()
                
                //set the buttons to enabled and not
                backButton.isEnabled = true
                forwardButton.isEnabled = false
            }
        }
        }
    }
}
