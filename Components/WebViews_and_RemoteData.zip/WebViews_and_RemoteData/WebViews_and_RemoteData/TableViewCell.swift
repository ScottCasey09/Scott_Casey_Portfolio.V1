//
//  TableViewCell.swift
//  WebViews_and_RemoteData
//
//  Created by Casey Scott on 11/13/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

   
    @IBOutlet weak var petColor: UILabel!
    @IBOutlet weak var petBreed: UILabel!
    @IBOutlet weak var petAge: UILabel!
    @IBOutlet weak var petName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
