//
//  Pets.swift
//  WebViews_and_RemoteData
//
//  Created by Casey Scott on 11/13/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import Foundation


class Pets{
    
    var name: String
    var age: String
    var breed: String
    var color: String
    
    
    init(name: String, age: String, breed: String, color: String) {
        
        self.name = name
        self.age = age
        self.breed = breed
        self.color = color
    }
}
