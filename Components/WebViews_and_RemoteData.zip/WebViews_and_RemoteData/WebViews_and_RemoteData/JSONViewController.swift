//
//  JSONViewController.swift
//  WebViews_and_RemoteData
//
//  Created by Casey Scott on 11/11/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import WebKit

class JSONViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, URLSessionDelegate {
    
   //Variables for this View
    var webView: WKWebView!
    var frame = CGRect(x: 0, y: 35, width: 375, height: 546)
    var petNames: [String] = []
    var petAges: [String] = []
    var petBreeds: [String] = []
    var petColors: [String] = []
    var pets: [Pets] = []
 
    //MARK: Outlets
    
    //Outlet for the tableView
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Instantiate a configuration
        let webConfiguration = WKWebViewConfiguration()
        
        //Set the size of the view
        webView = WKWebView(frame: frame, configuration: webConfiguration)
        
        //Instantiate an instance of a session configuration set to default
        let config = URLSessionConfiguration.default
        
        //Create a session
        let session = URLSession(configuration: config)
        
        //Creat an unwraped instance of a url type
        if let requestURl = URL(string: "https://data.kingcounty.gov/api/views/yaai-7frk/rows.json?accessType=DOWNLOAD"){
            //Create an Url request
            let requestedURL = URLRequest(url: requestURl)
            //Assign to a variable the data task
            let task = session.dataTask(with: requestedURL, completionHandler: { (data, response, error) in
                //Check against any errors
                if let error = error{
                    print("Faild with error: \(error)")
                    print(requestURl)
                    return
                }
                print("Success")
                //Check for success
                if let http = response as? HTTPURLResponse{
                    if http.statusCode == 200{
                        print("Success at 200")
                        
                        //Dispatch the queue to the main thred
                        DispatchQueue.main.async {
                           //Parse the remote data
                        self.parseJSON(data: data!)
                        }
                    }
                }
            })
            //resume the data task
            task.resume()
        }
    }
    
    //MARK: - UITableViewDataSource
    
    //Provide the number of rows each section will have
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pets.count
    }
    //Provide the table view with a section
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "     Dogs "
    }
    //Configure each cell in the table View
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Create a cell dequeuing any cell that can be
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCell
        
        //Assign the values of each pet object's properties to a cell
        cell.petName.text = pets[indexPath.row].name
        cell.petAge.text = pets[indexPath.row].age
        cell.petBreed.text = pets[indexPath.row].breed
        cell.petColor.text = pets[indexPath.row].color
        //Set the collor for each cell
        if indexPath.row % 2 == 0{
            cell.backgroundColor = UIColor(colorLiteralRed: 0.0, green: 1.0, blue: 0.8, alpha: 0.25)
        }else{
            cell.backgroundColor = UIColor(colorLiteralRed: 0.0, green: 1.0, blue: 0.8, alpha: 0.2)
        }
        //Return the cell
        return cell
    }
    
    //MARK: - Custom Functions
    
    //Function for parsing the JSON data
    private func parseJSON(data: Data){
        
        do{
            //Create an instance of the JSON to be able to convert it to objects
            let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
            //Start parsing throught the data and drill down to the next level
            if let rootDictionary: NSDictionary = json as? NSDictionary{
                //Find a key and use it to find the next value
                if let rootData = rootDictionary["meta"] as? NSDictionary{
                    //Find a key and use it to find the next value
                    if let columns = rootData["view"] as? NSDictionary{
                        //Find a key and use it to find the next value
                        if let name = columns["columns"] as? [NSDictionary]{
                            //Iterate over the array of keys to find the next values
                            for item in name{
                                //Pick out all of the desired objects at the name Key
                                if let name = item["name"] as? String{
                                    //Desired object check
                                    if name == "Animal_Name"{
                                        //Go deeper into this value and find more values
                                        if let title = item["cachedContents"] as? NSDictionary{
                                            //Pull the first value that is assigned with the "largest" key
                                            if let large = title["largest"] as? String{
                                                //Add the value to the array
                                                petNames.append(large)
                                            }//Find all other corrosponding values with the "top" key
                                            if let top = title["top"] as? [NSDictionary]{
                                                //Iterate over the array
                                                for tops in top{
                                                    //Pick out all of the "item" key values
                                                    if let items = tops["item"] as? String{
                                                        //Print to the console for debugging
                                                        print(items)
                                                        //Append the values to the array
                                                        petNames.append(items)
                                                    }
                                                }
                                            }//Pull out the last desired value for the specified key, which is keyed as "smallest"
                                            if let small = title["smallest"] as? String{
                                                //Add to the array
                                                petNames.append(small)
                                            }
                                        }
                                    }
                                    //Repeat the process after "columns" for each piece of data that is desired
                                    if name == "Age"{
                                        
                                        if let title = item["cachedContents"] as? NSDictionary{
                                            if let large = title["largest"] as? String{
                                                petAges.append(large)
                                            }
                                            if let top = title["top"] as? [NSDictionary]{
                                                for tops in top{
                                                    if let items = tops["item"] as? String{
                                                        print(items)
                                                        petAges.append(items)
                                                    }
                                                }
                                            }
                                            if let small = title["smallest"] as? String{
                                                petAges.append(small)
                                            }
                                        }
                                    }
                                    if name == "Animal_Color"{
                                        
                                        if let title = item["cachedContents"] as? NSDictionary{
                                            if let large = title["largest"] as? String{
                                                petColors.append(large)
                                            }
                                            if let top = title["top"] as? [NSDictionary]{
                                                for tops in top{
                                                    if let items = tops["item"] as? String{
                                                        print(items)
                                                        petColors.append(items)
                                                    }
                                                }
                                            }
                                            if let small = title["smallest"] as? String{
                                                petColors.append(small)
                                            }
                                        }
                                    }
                                    if name == "Animal_Breed"{
                                        
                                        if let title = item["cachedContents"] as? NSDictionary{
                                            if let large = title["largest"] as? String{
                                                petBreeds.append(large)
                                            }
                                            if let top = title["top"] as? [NSDictionary]{
                                                for tops in top{
                                                    if let items = tops["item"] as? String{
                                                        print(items)
                                                        petBreeds.append(items)
                                                    }
                                                }
                                            }
                                            if let small = title["smallest"] as? String{
                                                petBreeds.append(small)
                                            }
                                        }
                                    }
                                    
                                }
                                
                            }
                        }
                        //Create the pets objects
                        for i in 0...petNames.count-1{
                            pets.append(Pets(name: petNames[i], age: petAges[i], breed: petBreeds[i], color: petColors[i]))
                        }
                    }
                }
            }
            //If an error happens it needs to be caught
        }catch{
            print(error)
        }
        //Reload the tableView Data
        self.tableView.reloadData()
    }

}
