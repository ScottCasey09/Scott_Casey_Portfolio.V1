//
//  ViewController.swift
//  MapKit_Project
//
//  Created by Casey Scott on 11/7/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

//Private global Identifier
private let annoIdentifier = " Annotation"

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, UINavigationControllerDelegate{
    
    //Variable for the location manager
    var locationManager = CLLocationManager()
    //Variable for user Location Status
    var userLocationStatus: String = "Disabled"
    //Array for the annotations
    var arrayOfAnnotations: [MKAnnotation] = []
    //Array to populate the tableView in SettingsViewController
    var annos: [MKAnnotation] = []
    
    //MARK: Outlets
    
    @IBOutlet weak var locationToggleButton: UIButton!
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    
    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Prompt for permission
        let status = CLLocationManager.authorizationStatus()
        
        //Check to see if the user gives permition for location
        if status == .denied || status == .restricted{
            //Inform the user
            return
        }
        //Configure the starting location for the map
        let span = MKCoordinateSpan(latitudeDelta: 4, longitudeDelta: 4)
        let cordinate = CLLocationCoordinate2D(latitude: 28.346054, longitude: -81.266518)
        let region = MKCoordinateRegion(center: cordinate, span: span)
        map.setRegion(region, animated: true)
        
        //Add Annotations
        addAnnotationsToMap()
        //add the annotations to the constant array of annotations which is used for the tableView in the SettingViewController
        annos = arrayOfAnnotations
        //Assign the maps delegate to the view controller
        map.delegate = self

        //Assign the Location Managers Delegate to this view controller
        locationManager.delegate = self
        
        if status == .notDetermined{
            //Request access
            locationManager.requestWhenInUseAuthorization()
            
        }else if status == .authorizedAlways || status == .authorizedWhenInUse{
            //Continue as normal
        }
    }
    //Set the properties of the annotation pins and make them dragable - Called for each annotation
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation{
            return nil
        }
        //Dequeue the annotations to save memory
        var anno = mapView.dequeueReusableAnnotationView(withIdentifier: annoIdentifier) as? MKPinAnnotationView
        //Check for a nil annotation to prevent the user location from displaying the default pin icon, we want the beacon
        if anno == nil{
            anno = MKPinAnnotationView(annotation: annotation, reuseIdentifier: annoIdentifier)
        }
        //Set the properties and return the annotation
        anno?.isDraggable = true
        anno?.animatesDrop = true
        anno?.canShowCallout = true
        anno?.pinTintColor = #colorLiteral(red: 0.1764705926, green: 0.01176470611, blue: 0.5607843399, alpha: 1)
        return anno
        
    }
    
    //MARK: - CLLocationManagerDelegate
    
    //Error for in case location issues occur
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location Did Fail due to \(error)")
    }
    //Prints the current location in the console so I can see the location services running
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations)
    }
    
    //MARK: Actions
    
    @IBAction func changeViewOfMap(_ sender: AnyObject) {
        //change the map view base of of the segment selection
        //Constant of the selected index
        let index = segmentControl.selectedSegmentIndex
        //Conditions for selection 1-3
        if index == 0{
            map.mapType = .standard
        }else if index == 1{
            map.mapType = .satellite
        }else if index == 2{
            map.mapType = .hybrid
        }
    }
    //Turn on and off user locations based on the state of the button
    @IBAction func toggleUserLocation(_ sender: AnyObject) {
        if userLocationStatus == "Disabled"{
            locationManager.startUpdatingLocation()
            map.showsUserLocation = true
            userLocationStatus = "Enabled"
            locationToggleButton.setTitle("Turn Off Location", for: .normal)
        }else{
            locationManager.stopUpdatingLocation()
            map.showsUserLocation = false
            locationToggleButton.setTitle("Turn On Location", for: .normal)
            userLocationStatus = "Disabled"
            
        }
    }
    
    //MARK: Navigation
    
    //Prepare the view controller with the necessary data
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination as! SettingsViewController
        
        //If the map's annotations are not visable set the switch to off
        if arrayOfAnnotations.count == 0 {
            destination.annoSwitchBool = false
        }
        //Pass this viewController to the SettingsViewController as a delegate
        destination.delegate = self
        //Assign the value for the user location status
        destination.locationStatus = userLocationStatus
        //Pass the array of annotations (annos) for the Table View Display
        destination.annotations = annos
    }
    
    //MARK: Data Function
    
    //Function for creating the anotations for the map and adding them to the map
    func addAnnotationsToMap(){
        let annotation1 = MKPointAnnotation()
        annotation1.coordinate = CLLocationCoordinate2D(latitude: 28.346054, longitude: -81.266518)
        annotation1.title = "My Home"
        annotation1.subtitle = "This is where I live."
        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = CLLocationCoordinate2D(latitude: 28.016249, longitude: -81.928462)
        annotation2.title = "Another Place"
        annotation2.subtitle = "Lakeland Location"
        let annotation3 = MKPointAnnotation()
        annotation3.coordinate = CLLocationCoordinate2D(latitude: 28.000000, longitude: -81.000000)
        annotation3.title = "Central Florida Location"
        annotation3.subtitle = "A place in central florida"
        let annotation4 = MKPointAnnotation()
        annotation4.coordinate = CLLocationCoordinate2D(latitude: 28.646461, longitude: -81.125498)
        annotation4.title = "A Different Locatioin"
        annotation4.subtitle = "This place is here"
        let annotation5 = MKPointAnnotation()
        annotation5.coordinate = CLLocationCoordinate2D(latitude: 29.00000, longitude: -82.00000)
        annotation5.title = " Random Location"
        annotation5.subtitle = "Ocala Location"
        
        arrayOfAnnotations = [annotation5, annotation4, annotation2, annotation1, annotation3]
        
        map.addAnnotations(arrayOfAnnotations)
    }
}

