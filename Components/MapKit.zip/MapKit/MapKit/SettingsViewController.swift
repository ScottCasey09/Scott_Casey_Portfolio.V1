//
//  SettingsViewController.swift
//  MapKit_Project
//
//  Created by Casey Scott on 11/7/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit
import MapKit

class SettingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    //Properties of the viewController
    var locationStatus: String?
    var annotations: [MKAnnotation] = []
    var delegate: ViewController?
    var annoSwitchBool: Bool = true
    
    //MARK: Outlets
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var annoSwitch: UISwitch!
    @IBOutlet weak var tableView: UITableView!
    
    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Assign values to UI Elements
        if locationStatus == "Disabled"{
        statusLabel.textColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
        }else{
            statusLabel.textColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
        }
        statusLabel.text = locationStatus
       annoSwitch.isOn = annoSwitchBool
        if annoSwitchBool == false{
            annoSwitch.isOn = false
        }
    }
    
    //MARK: Actions
    
    //Action for when the user toggles the annotations on and off
    @IBAction func showAnnotations(_ sender: AnyObject) {
        
        if  annoSwitch.isOn == true {
            delegate?.map.addAnnotations((delegate?.arrayOfAnnotations)!)
            delegate?.addAnnotationsToMap()
        }
        else{
            delegate?.map.removeAnnotations((delegate?.arrayOfAnnotations)!)
            delegate?.arrayOfAnnotations = []
        }
    }
    
    //MARK: - UITableView
    
    //Assign the number of rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return annotations.count
    }
    //Assign the number of sections
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    //Create the cell for the TableView and populate the information
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCell
        //Unwrap the optional values
        if let annoTitle = annotations[indexPath.row].title{
        cell.titleLabel.text = annoTitle
        }
        if let annoSubTitle = annotations[indexPath.row].subtitle{
            cell.subTitleLabel?.text = annoSubTitle
        }
        return cell
    }
    //Make a generic header for the annotations
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Annotations"
    }
}
