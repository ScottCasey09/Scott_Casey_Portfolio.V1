﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SupplyListApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void saveListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stream myStream;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if ((myStream = saveFileDialog1.OpenFile()) != null)
                {

                    using (StreamWriter sw = new StreamWriter(myStream))
                    {
                        sw.WriteLine("Need List:");
                        foreach (String item in needListBox.Items)
                        {
                            sw.WriteLine(item);
                        }
                        sw.WriteLine("\r\nHave List:");
                        foreach (String item in haveListBox.Items)
                        {
                            sw.WriteLine(item);

                        }

                    }
                    myStream.Close();
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (ItemTextbox.Text == "" || ItemTextbox.Text == null)
            {
                //Do nothing
            }
            else
            {
                needListBox.Items.Add(ItemTextbox.Text);
                ItemTextbox.Text = "";
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ItemTextbox.Text == "" || ItemTextbox.Text == null)
            {
                //Do nothing
            }
            else
            {
                haveListBox.Items.Add(ItemTextbox.Text);
                ItemTextbox.Text = "";
            }
        }
        private void downArrowNeedtoHave_Click(object sender, EventArgs e)
        {
            if (needListBox.SelectedItems.Count > 0)
            {
                haveListBox.Items.Add(needListBox.SelectedItem);
                needListBox.Items.Remove(needListBox.SelectedItem);

            }
        }

        private void upArrowHavetoNeed_Click(object sender, EventArgs e)
        {
            if (haveListBox.SelectedItems.Count > 0)
            {
                needListBox.Items.Add(haveListBox.SelectedItem);
                haveListBox.Items.Remove(haveListBox.SelectedItem);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            haveListBox.Items.Remove(haveListBox.SelectedItem);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            needListBox.Items.Remove(needListBox.SelectedItem);
        }

        
    }
}
