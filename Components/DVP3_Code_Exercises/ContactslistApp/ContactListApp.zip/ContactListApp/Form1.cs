﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ContactListApp
{
    public partial class Form1 : Form
    {
        public EventHandler<ModifyObjectEventArgs> ModifyObject;


        public Contact SelectedObject
        {
            get
            {
                if (contactList.Items.Count > 0)
                {
                    return contactList.SelectedItems[0].Tag as Contact;
                }
                else
                {
                    return new Contact();
                }
            }
        }
        public Form1()
        {
            InitializeComponent();
        }
    

        public void addContactHandler(object sender, EventArgs e)
        {
            InputDialog id = sender as InputDialog;
            int number;

            
                if (id.firstNambeTextBox.Text != "" || id.lastNameTextBox.Text != "")
                {



                    if (new EmailAddressAttribute().IsValid(id.emaliTextBox.Text))
                    {

                        if (int.TryParse(id.areaCodeTextBox.Text, out number) && int.TryParse(id.firstPhoneNumberDigitsTextBox.Text, out number) && int.TryParse(id.lastPhoneNumberDigitsTextBox.Text, out number))

                        {
                            if (id.areaCodeTextBox.Text.Length == 3 && id.firstPhoneNumberDigitsTextBox.Text.Length == 3 && id.lastPhoneNumberDigitsTextBox.Text.Length == 4)
                            {
                                ListViewItem lvi = new ListViewItem();
                                lvi.Text = id.Data.ToString();
                                lvi.ImageIndex = 0;
                                lvi.Tag = id.Data;
                                contactList.Items.Add(lvi);
                                id.Data = new Contact();

                            }
                            else { MessageBox.Show("Invalid phone number."); }
                        }
                        else { MessageBox.Show("Invalid phone number."); }
                    }
                    else { MessageBox.Show("Email is in wrong format. someone@somewhere.com"); }
                }
                else { MessageBox.Show("Please enter a first and/or last name."); }
            }
               
        public class ModifyObjectEventArgs : EventArgs
        {
            ListViewItem ObjectToModify;
            public ListViewItem ItemToModifyProperty
            {
                get
                {
                    return ObjectToModify;
                }
                set
                {
                    ObjectToModify = value;
                }
            }
            public ModifyObjectEventArgs(ListViewItem lvi)
            {
                ObjectToModify = lvi;
            }
        }




        public void contactListDoubleClickedHandler(object sender, EventArgs e)
        {
            ModifyObject?.Invoke(this, new ModifyObjectEventArgs(contactList.SelectedItems[0]));
            
        }

        private void addContactButton_Click(object sender, EventArgs e)
        {
            InputDialog id = new InputDialog();
            id.upDateButton.Visible = false;
            id.UpdateContactEvent += contactListDoubleClickedHandler;
            id.AddContactEvent += addContactHandler;
            ModifyObject += id.HandleModifyObject;
            id.ShowDialog();
        }


        private void contactList_DoubleClick(object sender, EventArgs e)
        {
            InputDialog id = new InputDialog();
            id.upDateButton.Visible = true;
            id.UpdateContactEvent += contactListDoubleClickedHandler;
            id.AddContactEvent += addContactHandler;
            ModifyObject += id.HandleModifyObject;
            id.Data = SelectedObject;
            id.ShowDialog();
        }

        private void x16ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(x16ToolStripMenuItem.Checked == false)
            {
                contactList.View = View.SmallIcon;
                x32ToolStripMenuItem.Checked = false;
                x16ToolStripMenuItem.Checked = true;
            }
            
        }

        private void x32ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(x32ToolStripMenuItem.Checked == false)
            {
                contactList.View = View.LargeIcon;
                x16ToolStripMenuItem.Checked = false;
                x32ToolStripMenuItem.Checked = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            x16ToolStripMenuItem.Checked = true;
            contactList.View = View.SmallIcon;
        }
    }
}
