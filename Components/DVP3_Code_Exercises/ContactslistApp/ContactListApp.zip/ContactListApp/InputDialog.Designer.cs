﻿namespace ContactListApp
{
    partial class InputDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.upDateButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lastPhoneNumberDigitsTextBox = new System.Windows.Forms.TextBox();
            this.firstPhoneNumberDigitsTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.firstNambeTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.areaCodeTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.emaliTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.addButton = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // upDateButton
            // 
            this.upDateButton.AutoSize = true;
            this.upDateButton.Location = new System.Drawing.Point(12, 242);
            this.upDateButton.Name = "upDateButton";
            this.upDateButton.Size = new System.Drawing.Size(252, 58);
            this.upDateButton.TabIndex = 15;
            this.upDateButton.Text = "Update";
            this.upDateButton.UseVisualStyleBackColor = true;
            this.upDateButton.Visible = false;
            this.upDateButton.Click += new System.EventHandler(this.upDateButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lastPhoneNumberDigitsTextBox);
            this.groupBox1.Controls.Add(this.firstPhoneNumberDigitsTextBox);
            this.groupBox1.Controls.Add(this.lastNameTextBox);
            this.groupBox1.Controls.Add(this.firstNambeTextBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.areaCodeTextBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.emaliTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(250, 200);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Contact";
            // 
            // lastPhoneNumberDigitsTextBox
            // 
            this.lastPhoneNumberDigitsTextBox.Location = new System.Drawing.Point(186, 110);
            this.lastPhoneNumberDigitsTextBox.MaxLength = 4;
            this.lastPhoneNumberDigitsTextBox.Name = "lastPhoneNumberDigitsTextBox";
            this.lastPhoneNumberDigitsTextBox.Size = new System.Drawing.Size(52, 26);
            this.lastPhoneNumberDigitsTextBox.TabIndex = 11;
            // 
            // firstPhoneNumberDigitsTextBox
            // 
            this.firstPhoneNumberDigitsTextBox.Location = new System.Drawing.Point(138, 110);
            this.firstPhoneNumberDigitsTextBox.MaxLength = 3;
            this.firstPhoneNumberDigitsTextBox.Name = "firstPhoneNumberDigitsTextBox";
            this.firstPhoneNumberDigitsTextBox.Size = new System.Drawing.Size(42, 26);
            this.firstPhoneNumberDigitsTextBox.TabIndex = 10;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(94, 78);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(144, 26);
            this.lastNameTextBox.TabIndex = 3;
            // 
            // firstNambeTextBox
            // 
            this.firstNambeTextBox.Location = new System.Drawing.Point(94, 46);
            this.firstNambeTextBox.Name = "firstNambeTextBox";
            this.firstNambeTextBox.Size = new System.Drawing.Size(144, 26);
            this.firstNambeTextBox.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Email";
            // 
            // areaCodeTextBox
            // 
            this.areaCodeTextBox.Location = new System.Drawing.Point(94, 110);
            this.areaCodeTextBox.MaxLength = 3;
            this.areaCodeTextBox.Name = "areaCodeTextBox";
            this.areaCodeTextBox.Size = new System.Drawing.Size(38, 26);
            this.areaCodeTextBox.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Phone #";
            // 
            // emaliTextBox
            // 
            this.emaliTextBox.Location = new System.Drawing.Point(94, 142);
            this.emaliTextBox.Name = "emaliTextBox";
            this.emaliTextBox.Size = new System.Drawing.Size(144, 26);
            this.emaliTextBox.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "First Name";
            // 
            // addButton
            // 
            this.addButton.AutoSize = true;
            this.addButton.Location = new System.Drawing.Point(12, 306);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(252, 58);
            this.addButton.TabIndex = 13;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(276, 33);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(50, 29);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(211, 30);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // InputDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(276, 376);
            this.Controls.Add(this.upDateButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "InputDialog";
            this.Text = "InputDialog";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        public System.Windows.Forms.TextBox lastPhoneNumberDigitsTextBox;
        public System.Windows.Forms.TextBox firstPhoneNumberDigitsTextBox;
        public System.Windows.Forms.TextBox lastNameTextBox;
        public System.Windows.Forms.TextBox firstNambeTextBox;
        public System.Windows.Forms.TextBox areaCodeTextBox;
        public System.Windows.Forms.TextBox emaliTextBox;
        public System.Windows.Forms.Button upDateButton;
    }
}