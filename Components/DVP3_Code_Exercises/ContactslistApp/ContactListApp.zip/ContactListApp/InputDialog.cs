﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactListApp
{
    public partial class InputDialog : Form
    {
        public EventHandler AddContactEvent;
        public EventHandler UpdateContactEvent;
 

        public Contact Data
        {
            get
            {
                Contact c = new Contact();
                c.FirstName = firstNambeTextBox.Text;
                c.LastName = lastNameTextBox.Text;
                c.AreaCode = areaCodeTextBox.Text;
                c.FirstPhoneNumberDigits = firstPhoneNumberDigitsTextBox.Text;
                c.LastPhoneNumberDigits = lastPhoneNumberDigitsTextBox.Text;
                c.EmailAddress = emaliTextBox.Text;
                return c;
            }
            set
            {
                firstNambeTextBox.Text = value.FirstName;
                lastNameTextBox.Text = value.LastName;
                areaCodeTextBox.Text = value.AreaCode;
                firstPhoneNumberDigitsTextBox.Text = value.FirstPhoneNumberDigits;
                lastPhoneNumberDigitsTextBox.Text = value.LastPhoneNumberDigits;
                emaliTextBox.Text = value.EmailAddress;
            }

        }

        public InputDialog()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            AddContactEvent?.Invoke(this, new EventArgs());
            Close();
        }

        private void upDateButton_Click(object sender, EventArgs e)
        {
            UpdateContactEvent?.Invoke(this, new EventArgs());
          
            upDateButton.Visible = true;
        }
        public void HandleModifyObject(object sender, Form1.ModifyObjectEventArgs e)
        {

            Contact c = e.ItemToModifyProperty.Tag as Contact;
            c.FirstName = firstNambeTextBox.Text;
            c.LastName = lastNameTextBox.Text;
            c.AreaCode = areaCodeTextBox.Text;
            c.FirstPhoneNumberDigits = firstPhoneNumberDigitsTextBox.Text;
            c.LastPhoneNumberDigits = lastPhoneNumberDigitsTextBox.Text;
            c.EmailAddress = emaliTextBox.Text;

            e.ItemToModifyProperty.Text = c.ToString();
            e.ItemToModifyProperty.ImageIndex = 0;
            Close();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
