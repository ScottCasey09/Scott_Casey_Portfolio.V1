﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactListApp
{
    public class Contact
    {
        string firstName;
        string lastName;
        string lastPhoneNumberDigits;
        string emailAddress;
        string areaCode;
        string firstPhoneNumberDigits;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public string AreaCode
        {
            get { return areaCode; }
            set { areaCode = value; }
        }
        public string FirstPhoneNumberDigits
        {
            get { return firstPhoneNumberDigits; }
            set { firstPhoneNumberDigits = value; }
        }
        public string LastPhoneNumberDigits
        {
            get { return lastPhoneNumberDigits; }
            set { lastPhoneNumberDigits = value; }
        }
        public string EmailAddress
        {
            get { return emailAddress; }
            set { emailAddress = value; }
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(5);
            sb.Append(areaCode + "-" + firstPhoneNumberDigits + "-" + lastPhoneNumberDigits);
            return firstName + " " + lastName+"\r\n"+sb+"\r\n"+emailAddress;
        }
    }
}
