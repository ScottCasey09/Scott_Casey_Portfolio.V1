﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    
    

    public partial class TicTacToeBoard : Control
    {
       public Player player1 = new Player();
        public Player player2 = new Player();
       public  bool gameOn = false;

        public EventHandler Updatep1ScoreEvent;
        public EventHandler Updatep2ScoreEvent;
        public EventHandler ChangeP1TurnEvent;
        public EventHandler ChangeP2TurnEvent;



        public int turn = 1;

        Bitmap destroyer = Properties.Resources.kspaceduel;
        Bitmap cruiser = Properties.Resources.alienblaster;
        
       
        Size tileSize = new Size(64, 64);
        [Category("Map")]
        [Description("The width and height of the tiles.")]
        public Size TileSize
        {
            get { return tileSize; }
            set { tileSize = value; }
        }
        Bitmap tileSetImage = Properties.Resources.destroyer;
        [Category("Map")]
        [Description("The image used for drawing the tiles.")]
        public Bitmap TileSetImage
        {
            get { return tileSetImage; }
            set { tileSetImage = value; }
        }
        Point selectedtile = new Point(0, 0);
        [Category("Map")]
        [Description("The currently selected tile to draw.")]
        public Point SelectedTile
        {
            get { return selectedtile; }
            set { selectedtile = value; }
        }
        Point[,] gameBoard = new Point[3, 3];
        [Category("Map")]
        [Description("The width and height of the MAP.")]
        public Size ClearedGameBoard
        {
            get { return new Size(gameBoard.GetLength(0), gameBoard.GetLength(1)); }
            set
            {
                gameBoard = new Point[3, 3];

                Invalidate();
            }
        }
        public Point[,] GameBoard
        {
            get { return gameBoard; }
            set { gameBoard = value; }
        }
        Point[,] mapBuilderPointArray = new Point[10, 10];
        public Point[,] MapBuilderPointArray
        {
            get { return mapBuilderPointArray; }
            set { mapBuilderPointArray = value; }
        }
        public TicTacToeBoard()
        {
            InitializeComponent();
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.UserPaint, true);
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            for (int x = 0; x < gameBoard.GetLength(0); x++)
            {
                for (int y = 0; y < gameBoard.GetLength(1); y++)
                {
                    Rectangle destRect = Rectangle.Empty;
                    destRect.X = x * tileSize.Width;
                    destRect.Y = y * tileSize.Height;
                    destRect.Size = tileSize;

                    Rectangle srcRect = Rectangle.Empty;
                    srcRect.X = gameBoard[x, y].X * tileSize.Width;
                    srcRect.Y = gameBoard[x, y].Y * tileSize.Height;
                    srcRect.Size = tileSize;

                    pe.Graphics.DrawImage(Properties.Resources.Stars, destRect);
                    if (gameBoard[x, y].X == player1.PlayerPosition && gameBoard[x, y].Y == player1.PlayerPosition)
                    {
                        pe.Graphics.DrawImage(destroyer, destRect);
                    }
                    else if (gameBoard[x, y].X == player2.PlayerPosition && gameBoard[x, y].Y == player2.PlayerPosition)
                    {
                        
                        pe.Graphics.DrawImage(cruiser, destRect);
                    }

                    pe.Graphics.DrawRectangle(Pens.Red, destRect);

                }
              
            }
      
            base.OnPaint(pe);
         
        }

     

        private void MapControl_MouseClick(object sender, MouseEventArgs e)
        {
            if (gameOn == true)
            {

            Point mouseLocat = e.Location;

                if (mouseLocat.X <= tileSize.Width * ClearedGameBoard.Width && mouseLocat.Y <= tileSize.Height * ClearedGameBoard.Height)
                {


                    mouseLocat.X = mouseLocat.X / tileSize.Width;
                    mouseLocat.Y = mouseLocat.Y / tileSize.Height;

                    while (gameBoard[mouseLocat.X, mouseLocat.Y].X == 0)
                    {

                        if (turn == player1.PlayerPosition)
                        {
                            gameBoard[mouseLocat.X, mouseLocat.Y] = new Point(1, 1);

                            turn = player2.PlayerPosition;
                            ChangeP1TurnEvent?.Invoke(this, new EventArgs());
                            
                            break;
                        }
                        else if (turn == player2.PlayerPosition)

                        {
                            gameBoard[mouseLocat.X, mouseLocat.Y] = new Point(2, 2);
                            turn = player1.PlayerPosition;
                            ChangeP2TurnEvent?.Invoke(this, new EventArgs());
                            break;
                        }

                    }
                    Invalidate();
                    if (turn == 1)
                    {
                        ChangeP2TurnEvent?.Invoke(this, new EventArgs());

                    }
                    if (turn == 2)
                    {
                        ChangeP1TurnEvent?.Invoke(this, new EventArgs());

                    }
                    if (checkWinner(player1.PlayerPosition) == true)
                    {
                        
                        MessageBox.Show("Player 1 Wins");
                        player1.Player1Score++;
                        gameBoard = new Point[3, 3];
                        if(turn == 1)
                        {
                            Updatep1ScoreEvent?.Invoke(this, new EventArgs());
                        }else
                            Updatep2ScoreEvent?.Invoke(this, new EventArgs());


                        turn = 1;
                        //ChangeP2TurnEvent?.Invoke(this, new EventArgs());
                       
                        Invalidate();
                    }
                    else if (checkWinner(player2.PlayerPosition) == true)
                    {
                        MessageBox.Show("Player 2 Wins");
                        player2.Player1Score++;
                        gameBoard = new Point[3, 3];
                        if(turn == 2)
                        {
                            Updatep2ScoreEvent?.Invoke(this, new EventArgs());

                        }else
                            Updatep1ScoreEvent?.Invoke(this, new EventArgs());
                        turn = 2;

                        //ChangeP1TurnEvent?.Invoke(this,new EventArgs());

                        Invalidate();

                    }
                    if (CheckForTie() == true)
                    {
                        MessageBox.Show("Tie Game!");
                        gameBoard = new Point[3, 3];
                        if(turn == 1)
                        {
                            ChangeP1TurnEvent?.Invoke(this, new EventArgs());
                            turn = 2;
                        }
                        else
                        {
                            ChangeP2TurnEvent?.Invoke(this, new EventArgs());
                            turn = 1;

                        }
                        Invalidate();
                    }
                }
                    
            }
            
        }
        private bool checkWinner(int playerX)
        {
            Point player = new Point(playerX, playerX);
            // check rows
            if (gameBoard[0, 0] == player && gameBoard[0, 1] == player && gameBoard[0, 2] == player) { return true; }
            if (gameBoard[1, 0] == player && gameBoard[1, 1] == player && gameBoard[1, 2] == player) { return true; }
            if (gameBoard[2, 0] == player && gameBoard[2, 1] == player && gameBoard[2, 2] == player) { return true; }

            // check columns
            if (gameBoard[0, 0] == player && gameBoard[1, 0] == player && gameBoard[2, 0] == player) { return true; }
            if (gameBoard[0, 1] == player && gameBoard[1, 1] == player && gameBoard[2, 1] == player) { return true; }
            if (gameBoard[0, 2] == player && gameBoard[1, 2] == player && gameBoard[2, 2] == player) { return true; }

            // check diags
            if (gameBoard[0, 0] == player && gameBoard[1, 1] == player && gameBoard[2, 2] == player) { return true; }
            if (gameBoard[0, 2] == player && gameBoard[1, 1] == player && gameBoard[2, 0] == player) { return true; }

           

            return false;
        }
        public bool CheckForTie()
        {
            Point tie = new Point(0, 0);

            // check tie
            if (gameBoard[0, 0] != tie && gameBoard[0, 1] != tie && gameBoard[0, 2] != tie && gameBoard[1, 0] != tie && gameBoard[1, 1] != tie && gameBoard[1, 2] != tie && gameBoard[2, 0] != tie && gameBoard[2, 1] != tie && gameBoard[2, 2] != tie)
            {
             
                return true;
            }
            return false;
        }
    }
    
}
