﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ticTacToeBoard1.Size = new Size(193, 193);
            ticTacToeBoard1.Updatep1ScoreEvent += Updatep1ScoreHandler;
            ticTacToeBoard1.Updatep2ScoreEvent += Updatep2ScoreHandler;
            ticTacToeBoard1.ChangeP1TurnEvent += ChangeP1TurnHandler;
            ticTacToeBoard1.ChangeP2TurnEvent += ChangeP2TurnHandler;

            label5.Visible = false;

        }
        private void Updatep1ScoreHandler(object sender, EventArgs e)
        {
            int i = 0;
            int.TryParse(player1Scorelabel.Text, out i);
            i++;
            player1Scorelabel.Text = i.ToString();

        }
        private void Updatep2ScoreHandler(object sender, EventArgs e)
        {
            int i = 0;
            int.TryParse(player2ScoreLabel.Text, out i);
            i++;
            player2ScoreLabel.Text = i.ToString();
        }


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void newGamebutton_Click(object sender, EventArgs e)
        {
            if (newGamebutton.Text == "New Game")
            {
                newGamebutton.Text = "Start Game";
                clearButton.Visible = false;
                checkBox1.Visible = true;
                checkBox2.Visible = true;
                checkBox1.Checked = true;
                checkBox2.Checked = false;
                label1.Visible = true;
                ticTacToeBoard1.gameOn = false;
                ticTacToeBoard1.GameBoard = new Point[3, 3];
                player1Scorelabel.Text = "0";
                player2ScoreLabel.Text = "0";
                label5.Visible = true;

                ticTacToeBoard1.Invalidate();




            }
            else if (newGamebutton.Text == "Start Game")
            {
                if (checkBox1.Checked == false && checkBox2.Checked == false)
                {
                    MessageBox.Show("Select a war craft");
                }
                else
                {
                    label5.Visible = true;
                    ticTacToeBoard1.GameBoard = new Point[3, 3];
                    if (checkBox1.Checked == true)
                    {
                        ticTacToeBoard1.player1.PlayerPosition = 1;
                        ticTacToeBoard1.player2.PlayerPosition = 2;
                        label3.Text = "Player 1";
                        label4.Text = "Player 2";
                        label5.Text = "Go player 1...";

                    }
                    else if (checkBox2.Checked == true)
                    {
                        ticTacToeBoard1.player2.PlayerPosition = 1;
                        ticTacToeBoard1.player1.PlayerPosition = 2;
                        label4.Text = "Player 1";
                        label3.Text = "Player 2";
                        label5.Text = "Go player 1...";

                    }
                    newGamebutton.Text = "New Game";
                    clearButton.Visible = true;
                    checkBox1.Visible = false;
                    checkBox2.Visible = false;
                    checkBox1.Checked = false;
                    checkBox2.Checked = false;
                    label1.Visible = false;
                    ticTacToeBoard1.gameOn = true;
                }
            }



        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            ticTacToeBoard1.GameBoard = new Point[3, 3];

            ticTacToeBoard1.Invalidate();
        }
        private void ChangeP1TurnHandler(object sender, EventArgs e)
        {
           
                label5.Text = "Go player 1";
            
        }
        private void ChangeP2TurnHandler(object sender, EventArgs e)
        {
           
                label5.Text = "Go player 2";
          
        }
        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {

            newGamebutton.Text = "Start Game";
            clearButton.Visible = false;
            checkBox1.Visible = true;
            checkBox2.Visible = true;
            checkBox1.Checked = true;
            checkBox2.Checked = false;
            label1.Visible = true;
            ticTacToeBoard1.gameOn = false;




        }

        private void clearBoardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ticTacToeBoard1.GameBoard = new Point[3, 3];

            ticTacToeBoard1.Invalidate();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            checkBox2.Checked = false;

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            checkBox1.Checked = false;

        }
    }
}
