﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    public class Player
    {
        int playerPostion = 1;
        int playerScore = 0;
        //int player1Score = 0;
        //int player1 = 2;

        public int PlayerPosition
        {
            get { return playerPostion; }

            set { playerPostion = value; }
        }
        //public int Player1
        //{
        //    get { return player1; }
        //    set { Player1 = value; }

        //}
        //public int Player1Score
        //{
        //    get { return player1Score; }
        //    set { player1Score = value; }
        //}
        public int Player1Score
        {
            get { return playerScore; }
            set { playerScore = value; }
        }
    }
}
