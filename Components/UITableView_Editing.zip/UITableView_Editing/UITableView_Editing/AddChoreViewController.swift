//
//  AddChoreViewController.swift
//  UITableView_Editing
//
//  Created by Casey Scott on 10/28/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class AddChoreViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    //Data for the picker View
    let categories = ["Other", "Weed Eat", "Treat Pests", "Sweep", "Dog Duty", "Dishes", "Clean Bathroom", "Vacume", "Pick Up", "Wipe Counters","Mow Grass"]
    let categoryType = ["Inside Chore", "Outside Chore"]
    
    //MARK: - UI Outlets
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var categoryPicker: UIPickerView!
    @IBOutlet weak var setTimeControl: UIStepper!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var titleLabel: UITextField!
    
    //MARK: - Load
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Actions
    
    //Action for responding to the stepper value changing
    @IBAction func SetTimeTapped(_ sender: AnyObject) {
        timeLabel.text = "\(String(Int(setTimeControl.value))) min."
    }
    //Action for responding to the go back button, do so without making any changes
    @IBAction func goBackButton(_ sender: AnyObject) {
        dismiss(animated: true, completion: nil)
    }
    //Action to respond to the add chore button and do so but performing a segue to the unwind method if the title field has a value
    @IBAction func addChore(_ sender: AnyObject) {
        if titleLabel.text == "" || titleLabel.text == " " || titleLabel.text == nil{
            //Display the error message if no value is found
            displayErrorMessage()
        }else{
            performSegue(withIdentifier: "UnwindToRoot", sender: self)
        }
    }
    
    //MARK: Keyboard
    
    //Resign the keyboard when done is pressed
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return false
    }
    //if the screen is touched in a empty space the keyboard is retracted
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    //MARK: PickerView
    
    //Establish the amount of components
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    //Establish the amount of rows for each component
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        switch component{
        case 0:
            return categoryType.count
        case 1:
            return categories.count
        default:
            return 0
        }
    }
    //Assign values to each row in each component
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch component{
        case 0:
            return categoryType[row]
        case 1:
            return categories[row]
        default:
            return ""
        }
    }
    //When the values of the Picker change then change the value of the image and Chore location automatically but the user still has the option of applying any selection
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 1{
        switch row {
        case 0:
            image.image = #imageLiteral(resourceName: "Other")
        case 1:
            image.image = #imageLiteral(resourceName: "WeedEat")
            pickerView.selectRow(1, inComponent: 0, animated: true)
        case 2:
            image.image = #imageLiteral(resourceName: "TreatAntHills")
            pickerView.selectRow(1, inComponent: 0, animated: true)
        case 3:
            image.image = #imageLiteral(resourceName: "SweepPorch")
            pickerView.selectRow(1, inComponent: 0, animated: true)
        case 4:
            image.image = #imageLiteral(resourceName: "TakeDogOut")
            pickerView.selectRow(1, inComponent: 0, animated: true)
        case 5:
            image.image = #imageLiteral(resourceName: "DoDishes")
            pickerView.selectRow(0, inComponent: 0, animated: true)
        case 6:
            image.image = #imageLiteral(resourceName: "CleanBath")
            pickerView.selectRow(0, inComponent: 0, animated: true)
        case 7:
            image.image = #imageLiteral(resourceName: "Vacume")
            pickerView.selectRow(0, inComponent: 0, animated: true)
        case 8:
            image.image = #imageLiteral(resourceName: "PickUP")
            pickerView.selectRow(0, inComponent: 0, animated: true)
        case 9:
            image.image = #imageLiteral(resourceName: "WipeCounter")
            pickerView.selectRow(0, inComponent: 0, animated: true)
        case 10:
            image.image = #imageLiteral(resourceName: "MowGrass")
            pickerView.selectRow(1, inComponent: 0, animated: true)
        default: break
            
        }
        }
    }
    
    //MARK: Functions
    
    //Function for the error message if chore title is equal to a blank space
    func displayErrorMessage(){
        //Create the alert message
        let alert = UIAlertController(title: "Warning", message: "You must enter a title for the chore your are creating.", preferredStyle: UIAlertControllerStyle.alert)
        
        //create a button so the user can dismis the message
        let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
        
        //Add the action button
        alert.addAction(ok)
        
        //Present the alert to the user
        present(alert, animated: true, completion: nil )
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
