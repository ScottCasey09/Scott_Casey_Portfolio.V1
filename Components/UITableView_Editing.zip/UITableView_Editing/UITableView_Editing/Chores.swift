//
//  Chores.swift
//  UITableView_Editing
//
//  Created by Casey Scott on 10/27/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import Foundation
import UIKit

class Chore{
    
    //MARK: Properties
    
    var title: String
    var image: UIImage
    var estimatedTime: String
    
    //MARK: Initializer
    
    init(title: String, estimatedTime: String, image: UIImage) {
        self.title = title
        self.estimatedTime = estimatedTime
        self.image = image
    }
    
    
}
