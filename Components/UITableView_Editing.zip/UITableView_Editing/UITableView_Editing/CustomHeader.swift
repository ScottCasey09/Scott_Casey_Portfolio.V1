//
//  CustomHeader.swift
//  UITableView_Editing
//
//  Created by Casey Scott on 10/27/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class CustomHeader: UITableViewHeaderFooterView {


   
    @IBOutlet weak var headerLabel: UILabel!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
}
