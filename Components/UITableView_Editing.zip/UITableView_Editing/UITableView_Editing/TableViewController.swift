//
//  TableViewController.swift
//  UITableView_Editing
//
//  Created by Casey Scott on 10/27/16.
//  Copyright © 2016 Casey Scott. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController, UIAlertViewDelegate, UITextFieldDelegate {

    //MARK: Identifiers

    let cellIndentifer = "Cell"
    let headerIdentifier = "Header"
    let segueToAddChore = "GoToDetailsController"
    let nibIdentifier = "CustomHeaderCodeFile"
    
    //MARK: Properties
    
    var insideChores: [Chore] = []
    var outsideChores: [Chore] = []
   
    //MARK: Load
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Manually assign the Indetifier to the nib
        tableView.register(UINib(nibName: nibIdentifier, bundle: nil), forHeaderFooterViewReuseIdentifier: headerIdentifier)
        
        //Images for Data
        //Inside Chore Items
        let cleanBathroomImage = UIImage(named: "CleanBath")
        let wipeCounterImage = UIImage(named: "WipeCounter")
        let vacumeImage = UIImage(named: "Vacume")
        let doDishesImage = UIImage(named: "DoDishes")
        let pickUPImage = UIImage(named: "PickUP")
        
        //Outside Chore Items
        let takeDogOutImage = UIImage(named: "TakeDogOut")
        let mowGrassImage = UIImage(named: "MowGrass")
        let sweepPorchImage = UIImage(named: "SweepPorch")
        let treatAntHillsImage = UIImage(named: "TreatAntHills")
        let weedEatImage = UIImage(named: "WeedEat")
        
        //Data Items
        //Inside Chore Items
        let cleanBathChore = Chore(title: "Clean Bathroom", estimatedTime: "20 min.", image: cleanBathroomImage!)
        let wipeCountersChore = Chore(title: "Wipe Counters", estimatedTime: "20 min.", image: wipeCounterImage!)
        let doDishesChore = Chore(title: "Do Dishes", estimatedTime: "20 min.", image: doDishesImage!)
        let vacumeChore = Chore(title: "Vacume", estimatedTime: "30 min", image: vacumeImage!)
        let pickUpChore = Chore(title: "Pick UP", estimatedTime: "20 min.", image: pickUPImage!)
        
        //Outside Chore Items
        let takeDogOutChore = Chore(title: "Take Dog Out", estimatedTime: "5 min.", image: takeDogOutImage!)
        let sweepPorchChore = Chore(title: "Sweep Porch", estimatedTime: "10 min.", image: sweepPorchImage!)
        let treatAntHilChore = Chore(title: "Treat Ant Hills", estimatedTime: "20 min.", image: treatAntHillsImage!)
        let weedEatChore = Chore(title: "Weed Eat Yard", estimatedTime: "60 min.", image: weedEatImage!)
        let mowGrassChore = Chore(title: "Mow Grass", estimatedTime: "180 min.", image: mowGrassImage!)

        //Populate array of chores
        insideChores = [cleanBathChore, wipeCountersChore, vacumeChore, doDishesChore, pickUpChore]
        outsideChores = [takeDogOutChore, sweepPorchChore, treatAntHilChore, weedEatChore, mowGrassChore]
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        
        //self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
       
    //Hide status bar because it's in the way of the list
    override var prefersStatusBarHidden: Bool {
        return true
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    //Handle triggering editing mode for removing an item from the table view
    @IBAction func triggerEditModeButton(sender: UIButton){
    
        //Check if editing is on or off
        if isEditing == false {
            setEditing(true, animated: true)
        }else{
            setEditing(false, animated: true)
        }
    }
    //Handle trigering editing mode for adding a row
    @IBAction func addButton(sender: UIButton){
        
        //Add implementation for performing segue to a second view controller
        performSegue(withIdentifier: segueToAddChore, sender: self)
        
    }
    //Set the number of rows for each section in the table view
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        //Variable for counting each section and is assigned the value of each section's array count. Because there is only 2 sections I can use this method for assigning
        let count = section == 0 ? insideChores.count : outsideChores.count
        
        return count
    }
    //Set up the header labels
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: headerIdentifier) as! CustomHeader
       
            //Assign the headers a title because there is only 2 sections I can use this method for assigning value to the label.
            header.headerLabel.text = section == 0 ? "Inside Chores" : "Outside Chores"
     
        return header
    }
    //Set the size of the header
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100
    }
    //Provide the cells with some custom information
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Reuse cells
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIndentifer, for: indexPath) as! TableViewCell

        // Configure the cell...
        //Check the section and asign the correct values for each section
        if indexPath.section == 0{
            if insideChores.count > 0{
                cell.imageViewCell.image = insideChores[indexPath.row].image
                cell.titleChore.text = insideChores[indexPath.row].title
                cell.estimatedTimerChore.text = insideChores[indexPath.row].estimatedTime
                cell.backgroundColor = UIColor(colorLiteralRed: 0.4, green: 0.8, blue: 0.9, alpha: 0.3)
            }
        }
        else {
            if outsideChores.count > 0{
                cell.imageViewCell.image = outsideChores[indexPath.row].image
                cell.titleChore.text = outsideChores[indexPath.row].title
                cell.estimatedTimerChore.text = outsideChores[indexPath.row].estimatedTime
                cell.backgroundColor = UIColor(colorLiteralRed: 0.4, green: 0.8, blue: 0.9, alpha: 0.3)
            }
        }
        return cell
    }
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    // Override to support editing the table view.
    //Handle the deletion of the items in the list
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            //Create the alert message
            let alert = UIAlertController(title: "Warning", message: "Are you sure you want to remove this item?", preferredStyle: UIAlertControllerStyle.alert)
            
            //create a button so the user can dismis the message ad provide conditional actions based on which button os selected
            let yes = UIAlertAction(title: "Confirm", style: UIAlertActionStyle.default, handler: {action in
                //Adjust the data source by removing the chore item
                if indexPath.section == 0{
                    self.insideChores.remove(at: indexPath.row)
                }
                else if indexPath.section == 1{
                    self.outsideChores.remove(at: indexPath.row)
                }
                // Delete the row from the table view
                tableView.deleteRows(at: [indexPath], with: .fade)})
            //If the user selects cancel then do nothing
            let cancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: {action in})
            //Add the action button
            alert.addAction(yes)
            alert.addAction(cancel)
            
            //Present the alert to the user
            present(alert, animated: true, completion: nil )
            //Use this portion if the user is inserting an item, but because the insertion method is manually throught the custom header inserting an item is handled in a different way.
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */
    
    //Unwind Function to retrieve the values for the AddChoreViewController
    @IBAction func unwindToRoot(segue: UIStoryboardSegue)  {
        //Properties of this function
        let source = segue.source as! AddChoreViewController
        var title: String = ""
        var time: String = ""
        var image: UIImage = #imageLiteral(resourceName: "Other")
        //Unwrap optional values
        if let choreTitle = source.titleLabel.text{
            title = choreTitle
        }
        if let choreTime = source.timeLabel.text{
            time = choreTime + " min."
        }
        if let choreImage = source.image {
            image = choreImage.image!
        }
        //create new chore
        let chore = Chore(title: title, estimatedTime: time, image: image)
        //Add chore to the selected section
        if source.categoryPicker.selectedRow(inComponent: 0) == 0{
            insideChores.append(chore)
            self.tableView.reloadData()
        }else{
            outsideChores.append(chore)
            self.tableView.reloadData()
            
            
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
